// 云函数入口文件
const cloud = require('wx-server-sdk');
const crypto = require('crypto');

// 初始化云开发环境
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

// 获取数据库引用
const db = cloud.database();

/**
 * 获取用户openid
 * @returns {Promise<{openid: string, appid: string, unionid?: string}>} 用户身份信息
 */
const getOpenId = async () => {
  // 获取基础信息
  const wxContext = cloud.getWXContext();
  return {
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  };

/**
 * 删除指定的消息记录
 * @param {Object} event 包含消息ID的参数
 * @returns {Promise<{success: boolean, message?: string, errMsg?: string}>} 操作结果
 */
const deleteNotification = async (event) => {
  try {
    console.log('deleteNotification函数开始执行');
    
    const { notificationId } = event;
    if (!notificationId) {
      return {
        success: false,
        errMsg: '缺少消息ID'
      };
    }
    
    // 获取当前用户的openid
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    
    // 首先查询消息，验证所有权
    const notification = await db.collection('notifications').doc(notificationId).get();
    
    // 检查消息是否存在
    if (!notification.data) {
      return {
        success: false,
        errMsg: '消息不存在或已被删除'
      };
    }
    
    // 只有管理员或消息的所有者才能删除消息
    const userInfo = await db.collection('user').where({
      openid: openid
    }).get();
    
    const isAdmin = userInfo.data.length > 0 && userInfo.data[0].isAdmin;
    const isOwner = notification.data.userId === (userInfo.data.length > 0 ? userInfo.data[0]._id : '');
    
    // 普通用户只能删除自己的消息
    if (!isAdmin && !isOwner) {
      return {
        success: false,
        errMsg: '您无权删除此消息'
      };
    }
    
    // 执行删除操作
    await db.collection('notifications').doc(notificationId).remove();
    
    console.log('消息删除成功，ID:', notificationId);
    return {
      success: true,
      message: '消息已成功删除'
    };
  } catch (error) {
    console.error('删除消息失败:', error);
    return {
      success: false,
      errMsg: `删除消息失败：${error.message || '未知错误'}`
    };
  }
};
};

/**
 * 解密微信用户信息
 * @param {string} encryptedData 加密的数据
 * @param {string} sessionKey 会话密钥
 * @param {string} iv 加密向量
 * @returns {Object} 解密后的用户信息
 */
const decryptUserInfo = (encryptedData, sessionKey, iv) => {
  try {
    // base64解码
    const sessionKeyBuffer = Buffer.from(sessionKey, 'base64');
    const encryptedDataBuffer = Buffer.from(encryptedData, 'base64');
    const ivBuffer = Buffer.from(iv, 'base64');

    // AES解密
    const decipher = crypto.createDecipheriv('aes-128-cbc', sessionKeyBuffer, ivBuffer);
    // 设置自动 padding 为 true，删除填充补位
    decipher.setAutoPadding(true);
    let decoded = decipher.update(encryptedDataBuffer, 'binary', 'utf8');
    decoded += decipher.final('utf8');

    // 解析JSON数据
    const userInfo = JSON.parse(decoded);
    return userInfo;
  } catch (error) {
    console.error('解密用户信息失败:', error);
    throw new Error('解密用户信息失败');
  }
};

/**
 * 微信授权登录处理函数
 * @param {Object} event 包含code、encryptedData、iv等登录参数
 * @returns {Promise<{success: boolean, userInfo?: Object, errMsg?: string}>} 登录结果
 */
const wxLogin = async (event) => {
  try {
    console.log('wxLogin函数开始执行');
    console.log('接收到的完整event对象:', event);
    
    // 提取参数并设置默认值，确保即使没有参数也能正常运行
    let { code, encryptedData, iv, userInfo, isTest } = event || {};
    
    // 为了确保函数不会因缺少参数而失败，设置默认值
    code = code || (isTest ? 'default_test_code' : '');
    encryptedData = encryptedData || (isTest ? 'test_encrypted_data' : '');
    iv = iv || (isTest ? 'test_iv' : '');
    
    console.log('处理后的登录参数：', {
      hasCode: !!code,
      codeLength: code ? code.length : 0,
      hasEncryptedData: !!encryptedData,
      encryptedDataLength: encryptedData ? encryptedData.length : 0,
      hasIv: !!iv,
      ivLength: iv ? iv.length : 0,
      hasUserInfo: !!userInfo,
      isTest: !!isTest
    });

    // 校验必要参数 - 如果没有code，但是isTest为true，也允许通过
    if (!code && !isTest) {
      console.error('缺少必要的登录参数 - code', { hasCode: !!code, isTest: !!isTest });
      return {
        success: false,
        errMsg: '缺少必要的登录参数'
      };
    }
    
    // 标记是否为测试模式 - 只在明确的测试模式下使用模拟用户信息
    const isTestMode = isTest;
    console.log('是否为测试模式:', isTestMode, '判断依据:', { isTest });

    // 获取用户openid和appid（使用云开发内置能力）
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    const appid = wxContext.APPID;
    console.log('获取到用户openid:', openid, 'appid:', appid);
    
    // 注意：使用云函数的方式，不需要显式调用auth.code2Session获取session_key
    // 云开发会自动处理登录凭证验证，我们直接使用openid作为用户标识
    console.log('使用云开发内置能力处理登录，跳过显式的session_key获取');
    
    // 构建用户数据
    let userData;
    
    if (isTestMode) {
      // 测试模式：使用模拟用户信息
      console.log('测试模式：使用模拟用户信息');
      userData = {
        nickName: '测试用户',
        avatarUrl: '',
        gender: 0,
        city: '',
        province: '',
        country: '',
        language: 'zh_CN',
        isTestUser: true
      };
    } else {
      // 生产模式
      console.log('生产模式：处理用户信息');
      // 输出接收到的用户信息详情，用于调试
      console.log('接收到的用户信息详情:', JSON.stringify(userInfo || {}));
      
      // 检查是否有用户信息，如果有就使用
      if (userInfo) {
        // 即使nickName或avatarUrl为空，也先尝试使用传入的用户信息
        userData = {
          nickName: userInfo.nickName || '微信用户',
          avatarUrl: userInfo.avatarUrl || '',
          gender: userInfo.gender || 0,
          city: userInfo.city || '',
          province: userInfo.province || '',
          country: userInfo.country || '',
          language: userInfo.language || 'zh_CN'
        };
        console.log('使用传入的用户信息:', JSON.stringify(userData));
      } else {
        // 确实没有用户信息：使用基本用户信息
        console.log('确实没有用户信息：使用基本用户信息');
        userData = {
          nickName: '微信用户',
          avatarUrl: '',
          gender: 0,
          city: '',
          province: '',
          country: '',
          language: 'zh_CN'
        };
      }
    }

    // 查询用户是否已存在
    console.log('查询用户是否已存在');
    const { data: users } = await db.collection('users').where({
      openid: openid
    }).get();

    let user;
    if (users.length > 0) {
      // 用户已存在，更新用户信息
      user = users[0];
      console.log('用户已存在，更新用户信息');
      
      // 准备更新数据
      const updateData = {
        userInfo: userData,
        lastLoginTime: db.serverDate(),
        updateTime: db.serverDate()
      };
      
      // 在非测试模式下，确保用户数据中没有isTestUser标记
      if (!isTestMode && updateData.userInfo.isTestUser) {
        delete updateData.userInfo.isTestUser;
      }
      
      await db.collection('users').doc(user._id).update({
        data: updateData
      });
      user.userInfo = userData;
    } else {
      // 新用户，创建用户记录
      console.log('新用户，创建用户记录');
      const addResult = await db.collection('users').add({
        data: {
          openid: openid,
          userInfo: userData,
          createTime: db.serverDate(),
          lastLoginTime: db.serverDate()
        }
      });
      user = {
        _id: addResult._id,
        openid: openid,
        userInfo: userData
      };
    }

    // 返回登录成功结果
    const userInfoToReturn = {
      _id: user._id, // 添加用户ID字段，用于前端识别用户
      openid,
      ...user.userInfo,
      appId: cloud.getWXContext().APPID,
      loginTime: new Date().getTime()
    };
    
    // 在非测试模式下，确保移除isTestUser标记
    if (!isTestMode) {
      delete userInfoToReturn.isTestUser;
    }
    
    const result = {
      success: true,
      userInfo: userInfoToReturn,
      message: isTestMode ? '测试登录成功' : '登录成功'
    };
    console.log('wxLogin函数执行完成结果:', result);
    return result;
  } catch (e) {
    console.error('微信授权登录过程中发生错误：', e);
    return {
      success: false,
      errMsg: `登录失败：${e.message || '未知错误'}`
    };
  }
};

/**
 * 提交订单函数
 * @param {Object} event 包含订单数据的参数
 * @param {Object} db 数据库对象
 * @returns {Promise<{success: boolean, orderId?: string, errMsg?: string}>} 提交结果
 */
const submitOrder = async (event, db) => {
  try {
    console.log('submitOrder函数开始执行');
    console.log('接收到的订单数据:', event.orderData);
    
    // 添加详细日志，检查接收的参数
    console.log('云函数接收的submitOrder参数:', JSON.stringify(event));
    
    // 检查必要参数
    const { orderData } = event;
    if (!orderData) {
      console.error('缺少必要的订单数据');
      return {
        success: false,
        errMsg: '缺少必要的订单数据'
      };
    }
    
    // 检查用户ID
    console.log('从orderData中提取的userId:', orderData.userId);
    if (!orderData.userId) {
      console.error('缺少用户ID');
      return {
        success: false,
        errMsg: '用户身份验证失败'
      };
    }
    
    // 检查订单必填字段
    // 同时兼容旧版（code字段）和新版（codes数组）
    if ((!orderData.code && (!orderData.codes || orderData.codes.length === 0 || !orderData.codes.some(c => c))) || 
        !orderData.name || !orderData.address || !orderData.expressType) {
      console.error('订单信息不完整');
      return {
        success: false,
        errMsg: '订单信息不完整'
      };
    }
    
    // 检查快递数量
    const hasValidCount = orderData.sizes && orderData.sizes.some(item => item.count > 0);
    if (!hasValidCount) {
      console.error('快递数量必须大于0');
      return {
        success: false,
        errMsg: '快递数量必须大于0'
      };
    }
    
    // 补充订单信息
    const orderToSave = {
      ...orderData,
      createTime: orderData.createTime || db.serverDate(),
      status: 'pending', // 订单状态：pending(待处理), processing(处理中), completed(已完成), canceled(已取消)
      updateTime: db.serverDate()
    };
    
    // 保存订单到数据库
    console.log('准备保存订单到数据库:', orderToSave);
    const result = await db.collection('orders').add({
      data: orderToSave
    });
    
    console.log('订单保存成功，订单ID:', result._id);
    return {
      success: true,
      orderId: result._id,
      message: '订单提交成功'
    };
  } catch (e) {
    console.error('提交订单过程中发生错误：', e);
    return {
      success: false,
      errMsg: `提交订单失败：${e.message || '未知错误'}`
    };
  }
};

/**
 * 获取用户订单列表函数
 * @param {Object} event 包含用户ID的参数
 * @param {Object} db 数据库对象
 * @returns {Promise<{success: boolean, data?: Array, errMsg?: string}>} 订单列表结果
 */
const getOrders = async (event, db) => {
  try {
    console.log('getOrders函数开始执行');
    console.log('接收到的参数:', event);
    
    // 检查必要参数
    const { userId } = event;
    if (!userId) {
      console.error('缺少用户ID');
      return {
        success: false,
        errMsg: '用户身份验证失败'
      };
    }
    
    // 查询用户订单，按创建时间倒序排列
    console.log('查询用户订单，用户ID:', userId);
    const { data } = await db.collection('orders')
      .where({
        userId: userId
      })
      .orderBy('createTime', 'desc')
      .get();
    
    console.log('查询订单成功，订单数量:', data.length);
    return {
      success: true,
      data: data,
      message: '获取订单成功'
    };
  } catch (e) {
    console.error('获取订单过程中发生错误：', e);
    return {
      success: false,
      errMsg: `获取订单失败：${e.message || '未知错误'}`
    };
  }
};

/**
 * 批量获取订单详情函数
 * @param {Object} event 包含订单ID列表的参数
 * @param {Object} db 数据库对象
 * @returns {Promise<{success: boolean, data?: Array, errMsg?: string}>} 订单列表结果
 */
const getOrdersByIds = async (event, db) => {
  try {
    console.log('getOrdersByIds函数开始执行');
    console.log('接收到的参数:', event);
    
    // 检查必要参数
    const { orderIds } = event;
    if (!orderIds || !Array.isArray(orderIds) || orderIds.length === 0) {
      console.error('缺少订单ID列表或格式不正确');
      return {
        success: false,
        errMsg: '订单ID列表不能为空且必须为数组格式'
      };
    }
    
    // 根据订单ID列表查询订单详情
    console.log('批量查询订单详情，订单ID列表:', orderIds);
    const _ = db.command;
    const { data } = await db.collection('orders')
      .where({
        _id: _.in(orderIds)
      })
      .get();
    
    console.log('批量查询订单成功，订单数量:', data.length);
    return {
      success: true,
      data: data,
      message: '批量获取订单成功'
    };
  } catch (e) {
    console.error('批量获取订单过程中发生错误：', e);
    return {
      success: false,
      errMsg: `批量获取订单失败：${e.message || '未知错误'}`
    };
  }
};

/**
 * 发送工作人员订阅消息函数
 * @param {Object} event 包含订单数据的参数
 * @param {Object} db 数据库对象
 * @returns {Promise<{success: boolean, errMsg?: string}>} 发送结果
 */
const sendStaffSubscribeMessage = async (event, db) => {
  try {
    console.log('sendStaffSubscribeMessage函数开始执行');
    console.log('接收到的参数:', event);
    
    const { orderData } = event;
    if (!orderData) {
      console.error('缺少订单数据');
      return {
        success: true,
        message: '订单提交成功，但通知发送失败：缺少订单数据'
      };
    }
    
    // 工作人员openid和消息模板ID（根据用户提供的信息）
    const staffOpenid = 'oQHcB7B-lcSlMH5g3tJrqdxR1VUQ';
    const templateId = 'byyQTk0ycTcPoW8homGNtROnqW8wheC4exnyHSQ9DdA';
    
    console.log('使用的工作人员openid:', staffOpenid);
    console.log('使用的消息模板ID:', templateId);
    
    // 格式化日期时间
    const formatTime = (date) => {
      const d = new Date(date);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const hours = String(d.getHours()).padStart(2, '0');
      const minutes = String(d.getMinutes()).padStart(2, '0');
      const seconds = String(d.getSeconds()).padStart(2, '0');
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    };
    
    // 计算商品总数
    let totalItems = 0;
    if (orderData.sizes && Array.isArray(orderData.sizes)) {
      totalItems = orderData.sizes.reduce((sum, item) => sum + (item.count || 0), 0);
    }
    
    console.log('计算得到的商品总数:', totalItems);
    
    // 构建消息数据
    const messageData = {
      touser: staffOpenid,
      templateId: templateId,
      page: 'pages/order/order', // 点击消息跳转的页面
      data: {
        character_string1: {
          value: orderData._id || '暂未生成'
        },
        time2: {
          value: formatTime(orderData.createTime || new Date())
        },
        amount3: {
          value: (orderData.totalFee || 0).toFixed(2)
        },
        number7: {
          value: totalItems.toString()
        },
        phone_number23: {
          value: orderData.phone || '未提供'
        }
      }
    };
    
    console.log('准备发送订阅消息的数据:', messageData);
    
    // 确保云开发环境正确初始化
    if (!cloud) {
      console.error('云开发环境未初始化');
      return {
        success: true,
        message: '订单提交成功，但通知发送失败：云开发环境未初始化'
      };
    }
    
    // 检查是否有权限调用订阅消息API
    try {
      // 发送订阅消息
      const result = await cloud.openapi.subscribeMessage.send(messageData);
      console.log('工作人员订阅消息发送成功，结果:', result);
      
      return {
        success: true,
        message: '工作人员通知已发送',
        sendResult: result
      };
    } catch (apiError) {
      console.error('调用subscribeMessage.send API失败:', apiError);
      console.error('错误码:', apiError.errCode);
      console.error('错误信息:', apiError.errMsg);
      
      // 常见错误码处理
      let errorMsg = '订单提交成功，但通知发送失败';
      if (apiError.errCode === 40037) {
        errorMsg = '订单提交成功，但通知发送失败：订阅消息模板ID不正确';
      } else if (apiError.errCode === 40036) {
        errorMsg = '订单提交成功，但通知发送失败：订阅消息模板参数不正确';
      } else if (apiError.errCode === 43101) {
        errorMsg = '订单提交成功，但通知发送失败：用户拒绝接收消息';
      } else if (apiError.errCode === -501000) {
        errorMsg = '订单提交成功，但通知发送失败：openid无效';
      }
      
      return {
        success: true,
        message: errorMsg,
        errCode: apiError.errCode,
        errMsg: apiError.errMsg
      };
    }
  } catch (e) {
    console.error('发送工作人员订阅消息过程中发生错误：', e);
    // 注意：此功能失败不应影响订单提交流程，因此不返回错误给前端
    console.warn('发送工作人员订阅消息失败，但不影响订单状态');
    return {
      success: true,
      message: '订单提交成功，但通知发送失败：' + e.message,
      errorDetails: e
    };
  }
};

/**
 * 云函数入口函数
 */
/**
 * 检查用户权限（管理员和代取手）
 * @returns {Promise<{isAdmin: boolean, isCourier: boolean}>} 包含管理员和代取手权限的结果
 */
const checkUserPermissions = async () => {
  try {
    const [isAdmin, isCourier] = await Promise.all([checkAdmin(), checkCourier()]);
    return {
      isAdmin,
      isCourier,
      success: true
    };
  } catch (error) {
    console.error('检查用户权限失败:', error);
    return {
      isAdmin: false,
      isCourier: false,
      success: false,
      errMsg: error.message || '未知错误'
    };
  }
};

/**
 * 检查是否为管理员
 * @returns {Promise<boolean>} 是否为管理员
 */
const checkAdmin = async () => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    
    // 查询管理员集合
    const { data: admins } = await db.collection('admins').where({
      openid: openid
    }).get();
    
    return admins.length > 0;
  } catch (error) {
    console.error('检查管理员权限失败:', error);
    return false;
  }
};

/**
 * 添加管理员账号
 * @param {Object} event 包含adminOpenid的参数
 * @returns {Promise<{success: boolean, message?: string, errMsg?: string}>} 添加结果
 */
const addAdmin = async (event) => {
  try {
    console.log('addAdmin函数开始执行');
    
    // 只有当前管理员才能添加新管理员
    const isAdmin = await checkAdmin();
    if (!isAdmin) {
      return {
        success: false,
        errMsg: '无权限添加管理员'
      };
    }
    
    const { adminOpenid } = event;
    if (!adminOpenid) {
      return {
        success: false,
        errMsg: '缺少管理员openid'
      };
    }
    
    // 检查管理员是否已存在
    const { data: admins } = await db.collection('admins').where({
      openid: adminOpenid
    }).get();
    
    if (admins.length > 0) {
      return {
        success: false,
        errMsg: '该账号已为管理员'
      };
    }
    
    // 添加管理员
    await db.collection('admins').add({
      data: {
        openid: adminOpenid,
        createTime: db.serverDate()
      }
    });
    
    return {
      success: true,
      message: '管理员添加成功'
    };
  } catch (error) {
    console.error('添加管理员失败:', error);
    return {
      success: false,
      errMsg: `添加管理员失败：${error.message || '未知错误'}`
    };
  }
};

/**
 * 获取所有订单（管理员使用）
 * @param {Object} event 包含状态筛选参数
 * @returns {Promise<{success: boolean, data?: Array, errMsg?: string}>} 订单列表结果
 */
const getAllOrders = async (event) => {
  try {
    console.log('getAllOrders函数开始执行，event:', JSON.stringify(event));
    
    // 获取当前用户信息
    const wxContext = cloud.getWXContext();
    console.log('当前调用用户openid:', wxContext.OPENID);
    
    // 检查管理员权限
    const isAdmin = await checkAdmin();
    console.log('管理员权限检查结果:', isAdmin);
    
    // 获取参数
    const { status } = event;
    let query = db.collection('orders');
    
    // 根据状态筛选
    if (status) {
      console.log(`按状态筛选订单: ${status}`);
      query = query.where({
        status: status
      });
    }
    
    // 按创建时间倒序排列
    console.log('执行订单查询，按创建时间倒序');
    let data;
    
    // 管理员可以获取所有订单，非管理员限制返回100条
    if (isAdmin) {
      console.log('管理员模式：获取所有订单');
      const result = await query.orderBy('createTime', 'desc').get();
      data = result.data;
    } else {
      console.log('非管理员模式：限制获取100条订单');
      const result = await query.orderBy('createTime', 'desc').limit(100).get();
      data = result.data;
    }
    
    console.log(`查询结果：获取到 ${data.length} 个订单`);
    
    // 如果有订单，显示第一个订单的部分信息用于调试
    if (data.length > 0) {
      console.log('第一个订单信息:', {
        id: data[0]._id,
        createTime: data[0].createTime,
        status: data[0].status
      });
    }
    
    // 总是返回成功和订单数据，方便调试
    return {
      success: true,
      data: data,
      message: isAdmin ? '管理员获取订单成功' : '调试模式下获取订单成功',
      isAdmin: isAdmin,
      totalCount: data.length
    };
  } catch (error) {
    console.error('获取订单失败:', error);
    return {
      success: false,
      errMsg: `获取订单失败：${error.message || '未知错误'}`,
      errorDetails: JSON.stringify(error)
    };
  }
};

/**
 * 通过取件码搜索订单
 * @param {Object} event 包含取件码的参数
 * @returns {Promise<{success: boolean, data?: Array, errMsg?: string}>} 搜索结果
 */
const getOrdersByCode = async (event) => {
  try {
    console.log('getOrdersByCode函数开始执行');
    
    const { code } = event;
    if (!code) {
      return {
        success: false,
        errMsg: '缺少取件码'
      };
    }
    
    // 按取件码查询订单
    const { data } = await db.collection('orders')
      .where({
        code: db.RegExp({
          regexp: code,
          options: 'i' // 不区分大小写
        })
      })
      .orderBy('createTime', 'desc')
      .get();
    
    return {
      success: true,
      data: data,
      message: '搜索订单成功'
    };
  } catch (error) {
    console.error('搜索订单失败:', error);
    return {
      success: false,
      errMsg: `搜索订单失败：${error.message || '未知错误'}`
    };
  }
};

/**
 * 检查用户是否为代取手
 * @returns {Promise<boolean>} 是否为代取手
 */
const checkCourier = async () => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    
    // 先通过openid查询用户信息获取userId
    const { data: users } = await db.collection('users').where({
      openid: openid
    }).get();
    
    if (users.length === 0) {
      return false;
    }
    
    const userId = users[0]._id;
    
    // 再查询代取手集合，检查是否存在该userId且状态为active或pending的记录
    // 允许待审核状态的代取手接取订单
    const { data: couriers } = await db.collection('couriers').where({
      userId: userId,
      status: db.command.in(['active', 'pending'])
    }).get();
    
    return couriers.length > 0;
  } catch (error) {
    console.error('检查代取手权限失败:', error);
    return false;
  }
};

/**
 * 获取代取手列表
 * @param {Object} event 包含搜索关键词、状态筛选和分页参数
 * @returns {Promise<{success: boolean, data?: Array, errMsg?: string}>} 代取手列表结果
 */
const getCouriers = async (event) => {
  try {
    console.log('getCouriers函数开始执行');
    
    // 检查管理员权限
    const isAdmin = await checkAdmin();
    if (!isAdmin) {
      return {
        success: false,
        errMsg: '无权限获取代取手列表'
      };
    }
    
    const { searchKey, status, page = 1, pageSize = 20 } = event;
    
    // 构建查询条件
    let query = db.collection('couriers');
    
    // 搜索关键词筛选
    if (searchKey) {
      query = query.where({
        $or: [
          { name: db.RegExp({ regexp: searchKey, options: 'i' }) },
          { phone: db.RegExp({ regexp: searchKey, options: 'i' }) }
        ]
      });
    }
    
    // 状态筛选
    if (status && status !== 'all') {
      query = query.where({ status: status });
    }
    
    // 分页查询
    const skip = (page - 1) * pageSize;
    const { data } = await query.orderBy('createTime', 'desc').skip(skip).limit(pageSize).get();
    
    console.log(`获取代取手列表成功，共${data.length}条记录`);
    return {
      success: true,
      data: data,
      message: '获取代取手列表成功'
    };
  } catch (error) {
    console.error('获取代取手列表失败:', error);
    return {
      success: false,
      errMsg: `获取代取手列表失败：${error.message || '未知错误'}`
    };
  }
};

/**
 * 更新代取手状态
 * @param {Object} event 包含代取手ID和新状态的参数
 * @returns {Promise<{success: boolean, message?: string, errMsg?: string}>} 更新结果
 */
const updateCourierStatus = async (event) => {
  try {
    console.log('updateCourierStatus函数开始执行');
    
    // 检查管理员权限
    const isAdmin = await checkAdmin();
    if (!isAdmin) {
      return {
        success: false,
        errMsg: '无权限更新代取手状态'
      };
    }
    
    const { courierId, status } = event;
    
    if (!courierId || !status) {
      return {
        success: false,
        errMsg: '缺少代取手ID或状态'
      };
    }
    
    // 检查代取手是否存在
    const { data: couriers } = await db.collection('couriers').where({
      _id: courierId
    }).get();
    
    if (couriers.length === 0) {
      return {
        success: false,
        errMsg: '代取手不存在'
      };
    }
    
    // 更新代取手状态
    await db.collection('couriers').doc(courierId).update({
      data: {
        status: status,
        updateTime: db.serverDate()
      }
    });
    
    console.log('更新代取手状态成功，ID:', courierId, '新状态:', status);
    return {
      success: true,
      message: '代取手状态更新成功'
    };
  } catch (error) {
    console.error('更新代取手状态失败:', error);
    return {
      success: false,
      errMsg: `更新代取手状态失败：${error.message || '未知错误'}`
    };
  }
};

/**
 * 更新订单状态
 * @param {Object} event 包含订单ID和新状态的参数
 * @returns {Promise<{success: boolean, message?: string, errMsg?: string}>} 更新结果
 */
const updateOrderStatus = async (event) => {
  try {
    console.log('updateOrderStatus函数开始执行');
    
    // 检查管理员权限或代取手权限
    const isAdmin = await checkAdmin();
    const isCourier = await checkCourier();
    
    if (!isAdmin && !isCourier) {
      return {
        success: false,
        errMsg: '无权限更新订单状态'
      };
    }
    
    const { orderId, status, remark, courierId } = event;
    if (!orderId || !status) {
      return {
        success: false,
        errMsg: '缺少订单ID或状态'
      };
    }
    
    // 检查订单是否存在
    const { data: orders } = await db.collection('orders').where({
      _id: orderId
    }).get();
    
    if (orders.length === 0) {
      return {
        success: false,
        errMsg: '订单不存在'
      };
    }
    
    const order = orders[0];
    
    // 更新订单状态
    const updateData = {
      status: status,
      updateTime: db.serverDate()
    };
    
    if (remark) {
      updateData.remark = remark;
    }
    
    // 如果是完成订单操作，记录完成时间
    if (status === 'completed') {
      updateData.completeTime = db.serverDate(); // 记录完成订单的时间
    }
    
    // 如果是接单操作（status为processing），且提供了courierId，获取代取手信息
    if (status === 'processing' && courierId) {
      console.log('尝试获取代取手信息，传入的courierId:', courierId);
      
      // 先通过用户ID查询代取手信息（主要方式）
      let { data: couriers } = await db.collection('couriers').where({
        userId: courierId,
        status: db.command.in(['active', 'pending'])
      }).get();
      
      console.log('通过userId查询结果数量:', couriers.length);
      
      // 如果没找到，尝试通过_id查询（备选方式，兼容不同存储方式）
      if (couriers.length === 0) {
        console.log('尝试通过_id查询代取手信息');
        const idQueryResult = await db.collection('couriers').where({
          _id: courierId,
          status: db.command.in(['active', 'pending'])
        }).get();
        couriers = idQueryResult.data;
        console.log('通过_id查询结果数量:', couriers.length);
      }
      
      if (couriers.length > 0) {
        const courier = couriers[0];
        console.log('找到代取手信息:', { name: courier.name, phone: courier.phone });
        // 添加代取手信息到更新数据中
        updateData.courierId = courierId;
        updateData.courierName = courier.name || '代取手';
        updateData.courierPhone = courier.phone || '未提供';
        updateData.pickupTime = db.serverDate(); // 记录接单时间
      } else {
        console.warn('未找到有效代取手信息，可能是用户未注册为代取手或状态不是active/pending');
        // 即使找不到代取手信息，也添加courierId，以便追踪
        updateData.courierId = courierId;
        updateData.courierName = '未知代取手';
        updateData.courierPhone = '未提供';
        updateData.pickupTime = db.serverDate();
      }
    }
    
    await db.collection('orders').doc(orderId).update({
      data: updateData
    });
    
    // 发送通知给用户
    if (status === 'processing') {
      await sendNotificationToUser(order, '订单已被接收', '您的订单已被工作人员接收，正在处理中');
    } else if (status === 'completed') {
      await sendNotificationToUser(order, '订单已完成', remark || '您的订单已完成，感谢使用');
    } else if (status === 'rejected') {
      await sendNotificationToUser(order, '订单已被拒绝', remark || '您的订单已被拒绝，如有疑问请联系客服');
    }
    
    return {
      success: true,
      message: '订单状态更新成功'
    };
  } catch (error) {
    console.error('更新订单状态失败:', error);
    return {
      success: false,
      errMsg: `更新订单状态失败：${error.message || '未知错误'}`
    };
  }
};

/**
 * 发送通知给用户
 * @param {Object} order 订单信息
 * @param {string} title 通知标题
 * @param {string} content 通知内容
 * @returns {Promise<void>}
 */
const sendNotificationToUser = async (order, title, content) => {
  try {
    // 获取用户openid
    const { data: users } = await db.collection('users').where({
      _id: order.userId
    }).get();
    
    if (users.length === 0) {
      console.error('用户不存在，无法发送通知');
      return;
    }
    
    const user = users[0];
    
    // 保存通知到数据库
    await db.collection('notifications').add({
      data: {
        userId: order.userId,
        userOpenid: user.openid,
        orderId: order._id,
        title: title,
        content: content,
        isRead: false,
        createTime: db.serverDate()
      }
    });
    
    console.log('通知发送成功，用户ID:', order.userId, '订单ID:', order._id);
  } catch (error) {
    console.error('发送通知失败:', error);
  }
};

/**
 * 获取用户消息列表
 * @param {Object} event 包含用户ID的参数
 * @returns {Promise<{success: boolean, data?: Array, errMsg?: string}>} 消息列表结果
 */
const getNotifications = async (event) => {
  try {
    console.log('getNotifications函数开始执行');
    
    const { userId } = event;
    if (!userId) {
      return {
        success: false,
        errMsg: '缺少用户ID'
      };
    }
    
    // 查询用户消息，按创建时间倒序排列
    const { data } = await db.collection('notifications')
      .where({
        userId: userId
      })
      .orderBy('createTime', 'desc')
      .get();
    
    return {
      success: true,
      data: data,
      message: '获取消息成功'
    };
  } catch (error) {
    console.error('获取消息失败:', error);
    return {
      success: false,
      errMsg: `获取消息失败：${error.message || '未知错误'}`
    };
  }
};

/**
 * 标记消息为已读
 * @param {Object} event 包含消息ID的参数
 * @returns {Promise<{success: boolean, message?: string, errMsg?: string}>} 操作结果
 */
const markNotificationAsRead = async (event) => {
  try {
    console.log('markNotificationAsRead函数开始执行');
    
    const { notificationId } = event;
    if (!notificationId) {
      return {
        success: false,
        errMsg: '缺少消息ID'
      };
    }
    
    await db.collection('notifications').doc(notificationId).update({
      data: {
        isRead: true,
        readTime: db.serverDate()
      }
    });
    
    return {
      success: true,
      message: '消息已标记为已读'
    };
  } catch (error) {
    console.error('标记消息为已读失败:', error);
    return {
      success: false,
      errMsg: `标记消息为已读失败：${error.message || '未知错误'}`
    };
  }
};

// 导入第一个管理员添加工具
const addFirstAdmin = require('./addFirstAdmin');

/**
 * 清理超过指定天数的旧订单和消息记录
 * @param {Object} event 事件参数
 * @returns {Promise<{success: boolean, message?: string, errMsg?: string, cleanupResult?: {orders: number, notifications: number, courierOrders: number}}>} 清理结果
 */
const cleanupOldRecords = async (event) => {
  try {
    console.log('cleanupOldRecords函数开始执行');
    
    // 计算4天前的时间戳（全局默认清理时间）
    const fourDaysAgo = new Date();
    fourDaysAgo.setDate(fourDaysAgo.getDate() - 4);
    const globalCleanupTimestamp = fourDaysAgo.getTime();
    
    // 计算3天前的时间戳（代取手订单特殊清理时间）
    const threeDaysAgo = new Date();
    threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
    const courierCleanupTimestamp = threeDaysAgo.getTime();
    
    console.log('全局清理时间点：', new Date(globalCleanupTimestamp).toISOString());
    console.log('代取手订单清理时间点：', new Date(courierCleanupTimestamp).toISOString());
    
    // 1. 清理代取手的已完成和已拒绝订单（留存3天）
    const courierOrderResult = await db.collection('orders')
      .where({
        createTime: db.command.lt(courierCleanupTimestamp),
        status: db.command.in(['completed', 'rejected']),
        // 存在courierId字段表示是代取手处理的订单
        courierId: db.command.exists(true)
      })
      .remove();
    
    // 2. 清理非代取手的已完成、已拒绝和已取消订单（留存4天）
    const nonCourierOrderResult = await db.collection('orders')
      .where({
        createTime: db.command.lt(globalCleanupTimestamp),
        status: db.command.in(['completed', 'rejected', 'cancelled']),
        // 不存在courierId字段或courierId为空
        courierId: db.command.or(db.command.not(db.command.exists(true)), db.command.eq(''))
      })
      .remove();
    
    // 合并订单清理结果
    const orderResult = {
      deleted: courierOrderResult.deleted + nonCourierOrderResult.deleted
    };
    
    // 清理旧消息记录
    const notificationResult = await db.collection('notifications')
      .where({
        createTime: db.command.lt(timestamp)
      })
      .remove();
    
    console.log('清理结果 - 总订单：', orderResult.deleted, '条，代取手订单：', courierOrderResult.deleted, '条，非代取手订单：', nonCourierOrderResult.deleted, '条，消息：', notificationResult.deleted, '条');
    
    return {
      success: true,
      message: `清理成功，共清理${orderResult.deleted}条订单记录（其中代取手订单${courierOrderResult.deleted}条）和${notificationResult.deleted}条消息记录`,
      cleanupResult: {
        orders: orderResult.deleted,
        courierOrders: courierOrderResult.deleted,
        notifications: notificationResult.deleted
      }
    };
  } catch (error) {
    console.error('清理旧记录失败:', error);
    return {
      success: false,
      errMsg: `清理旧记录失败：${error.message || '未知错误'}`
    };
  }
};

/**
 * 代取手注册
 * @param {Object} event 包含代取手注册信息的参数
 * @returns {Promise<{success: boolean, message?: string, errMsg?: string}>} 注册结果
 */
const registerCourier = async (event) => {
  try {
    console.log('registerCourier函数开始执行');
    
    const { courierData } = event;
    
    if (!courierData) {
      return {
        success: false,
        errMsg: '缺少代取手注册数据'
      };
    }
    
    // 检查该用户是否已经提交过注册申请
    const { data: existingCouriers } = await db.collection('couriers').where({
      userId: courierData.userId
    }).get();
    
    if (existingCouriers.length > 0) {
      return {
        success: false,
        errMsg: '您已经提交过代取手注册申请，请等待审核'
      };
    }
    
    // 保存代取手注册信息到数据库
    const result = await db.collection('couriers').add({
      data: {
        ...courierData,
        createTime: db.serverDate() // 使用服务器时间
      }
    });
    
    console.log('代取手注册成功，ID:', result._id);
    
    // 发送通知给管理员
    const { data: admins } = await db.collection('user').where({
      isAdmin: true
    }).get();
    
    for (const admin of admins) {
      await db.collection('notifications').add({
        data: {
          userId: admin._id,
          userOpenid: admin.openid,
          title: '新的代取手申请',
          content: `用户${courierData.name}提交了代取手注册申请，请及时审核`,
          isRead: false,
          createTime: db.serverDate(),
          type: 'courier_application'
        }
      });
    }
    
    return {
      success: true,
      message: '代取手注册申请已提交，请等待管理员审核'
    };
  } catch (error) {
    console.error('代取手注册失败:', error);
    return {
      success: false,
      errMsg: `代取手注册失败：${error.message || '未知错误'}`
    };
  }
};

/**
 * 云函数入口函数
 */
exports.main = async (event, context) => {
  console.log('接收到云函数请求，完整参数：', event);
  
  try {
    // 获取操作类型
    const { type } = event;
    
    // 根据操作类型执行不同的业务逻辑
    if (type === 'registerCourier') {
      console.log('接收到registerCourier类型请求，准备执行registerCourier函数');
      // 执行代取手注册操作
      const registerResult = await registerCourier(event);
      console.log('registerCourier函数执行完成，结果:', registerResult);
      return registerResult;
    } else if (type === 'login') {
      console.log('接收到login类型请求，准备执行wxLogin函数');
      // 执行微信登录操作
      const loginResult = await wxLogin(event);
      console.log('wxLogin函数执行完成，结果:', loginResult);
      return loginResult;
    } else if (type === 'test') {
      // 测试云函数调用
      console.log('接收到测试云函数调用');
      return {
        success: true,
        message: '云函数测试调用成功',
        timestamp: new Date().getTime()
      };
    } else if (type === 'submitOrder') {
      console.log('接收到submitOrder类型请求，准备执行submitOrder函数');
      // 执行提交订单操作
      const orderResult = await submitOrder(event, db);
      console.log('submitOrder函数执行完成，结果:', orderResult);
      return orderResult;
    } else if (type === 'getOrders') {
      console.log('接收到getOrders类型请求，准备执行getOrders函数');
      // 执行获取订单列表操作
      const ordersResult = await getOrders(event, db);
      console.log('getOrders函数执行完成，结果:', ordersResult);
      return ordersResult;
    } else if (type === 'getOrdersByIds') {
      console.log('接收到getOrdersByIds类型请求，准备执行getOrdersByIds函数');
      // 执行批量获取订单详情操作
      const ordersResult = await getOrdersByIds(event, db);
      console.log('getOrdersByIds函数执行完成，结果:', ordersResult);
      return ordersResult;
    } else if (type === 'sendStaffSubscribeMessage') {
      console.log('接收到sendStaffSubscribeMessage类型请求，准备执行sendStaffSubscribeMessage函数');
      // 执行发送工作人员订阅消息操作
      const messageResult = await sendStaffSubscribeMessage(event, db);
      console.log('sendStaffSubscribeMessage函数执行完成，结果:', messageResult);
      return messageResult;
    } else if (type === 'checkAdmin') {
      console.log('接收到checkAdmin类型请求，准备执行checkAdmin函数');
      // 检查是否为管理员
      const isAdmin = await checkAdmin();
      console.log('checkAdmin函数执行完成，结果:', isAdmin);
      return {
        success: true,
        isAdmin: isAdmin
      }
    } else if (type === 'checkUserPermissions') {
      console.log('接收到checkUserPermissions类型请求，准备执行checkUserPermissions函数');
      // 检查用户权限（管理员和代取手）
      const permissionsResult = await checkUserPermissions();
      console.log('checkUserPermissions函数执行完成，结果:', permissionsResult);
      return permissionsResult;
    } else if (type === 'checkCourierStatus') {
      console.log('接收到checkCourierStatus类型请求，准备执行checkCourier函数');
      // 检查是否为代取手
      const isCourier = await checkCourier();
      console.log('checkCourier函数执行完成，结果:', isCourier);
      return {
        success: true,
        isCourier: isCourier
      };
    } else if (type === 'getCouriers') {
      console.log('接收到getCouriers类型请求，准备执行getCouriers函数');
      // 获取代取手列表
      const couriersResult = await getCouriers(event);
      console.log('getCouriers函数执行完成，结果:', couriersResult);
      return couriersResult;
    } else if (type === 'updateCourierStatus') {
      console.log('接收到updateCourierStatus类型请求，准备执行updateCourierStatus函数');
      // 更新代取手状态
      const updateResult = await updateCourierStatus(event);
      console.log('updateCourierStatus函数执行完成，结果:', updateResult);
      return updateResult;
    } else if (type === 'addAdmin') {
      console.log('接收到addAdmin类型请求，准备执行addAdmin函数');
      // 添加管理员
      const addResult = await addAdmin(event);
      console.log('addAdmin函数执行完成，结果:', addResult);
      return addResult;
    } else if (type === 'requestPayment') {
      console.log('接收到requestPayment类型请求');
      // 这里应该是获取支付参数的逻辑
      // 由于云开发环境限制，这里提供模拟的支付参数供测试使用
      return {
        success: true,
        paymentParams: {
          timeStamp: String(Date.now()),
          nonceStr: 'nonce_str_' + Date.now(),
          package: 'prepay_id=wx2312541234567890',
          signType: 'MD5',
          paySign: 'sign_' + Date.now()
        }
      };
    } else if (type === 'addFirstAdmin') {
      console.log('接收到addFirstAdmin类型请求，准备执行addFirstAdmin函数 - 注意：这是一个临时的权限绕过函数');
      // 添加第一个管理员（绕过权限检查）
      const addResult = await addFirstAdmin(event);
      console.log('addFirstAdmin函数执行完成，结果:', addResult);
      return addResult;
    } else if (type === 'getAllOrders') {
      console.log('接收到getAllOrders类型请求，准备执行getAllOrders函数');
      // 获取所有订单（管理员）
      const allOrdersResult = await getAllOrders(event);
      console.log('getAllOrders函数执行完成，结果:', allOrdersResult);
      return allOrdersResult;
    } else if (type === 'updateOrderStatus') {
      console.log('接收到updateOrderStatus类型请求，准备执行updateOrderStatus函数');
      // 更新订单状态
      const updateResult = await updateOrderStatus(event);
      console.log('updateOrderStatus函数执行完成，结果:', updateResult);
      return updateResult;
    } else if (type === 'getOrdersByCode') {
      console.log('接收到getOrdersByCode类型请求，准备执行getOrdersByCode函数');
      // 通过取件码搜索订单
      const searchResult = await getOrdersByCode(event);
      console.log('getOrdersByCode函数执行完成，结果:', searchResult);
      return searchResult;
    } else if (type === 'getNotifications') {
      console.log('接收到getNotifications类型请求，准备执行getNotifications函数');
      // 获取用户消息
      const notificationsResult = await getNotifications(event);
      console.log('getNotifications函数执行完成，结果:', notificationsResult);
      return notificationsResult;
    } else if (type === 'markNotificationAsRead') {
      console.log('接收到markNotificationAsRead类型请求，准备执行markNotificationAsRead函数');
      // 标记消息为已读
      const markResult = await markNotificationAsRead(event);
      console.log('markNotificationAsRead函数执行完成，结果:', markResult);
      return markResult;
    } else if (type === 'cleanupOldRecords') {
      console.log('接收到cleanupOldRecords类型请求，准备执行cleanupOldRecords函数');
      // 清理旧订单和消息记录
      const cleanupResult = await cleanupOldRecords(event);
      console.log('cleanupOldRecords函数执行完成，结果:', cleanupResult);
      return cleanupResult;
    } else if (type === 'deleteNotification') {
      console.log('接收到deleteNotification类型请求，准备执行deleteNotification函数');
      // 删除指定的消息记录
      const deleteResult = await deleteNotification(event);
      console.log('deleteNotification函数执行完成，结果:', deleteResult);
      return deleteResult;
    } else {
      // 其他未实现的操作类型
      console.warn('接收到未知的操作类型:', type);
      return {
        success: false,
        errMsg: '未知的操作类型'
      };
    }
  } catch (err) {
    console.error('云函数执行异常:', err);
    return {
      success: false,
      errMsg: `服务器错误：${err.message || '请稍后重试'}`
    };
  }
};
