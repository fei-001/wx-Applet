// 第一个管理员添加工具
// 这个脚本用于添加第一个管理员账号，绕过正常的管理员权限检查

// 初始化云开发环境
const cloud = require('wx-server-sdk');
cloud.init({  
  env: cloud.DYNAMIC_CURRENT_ENV,
});

// 获取数据库引用
const db = cloud.database();

/**
 * 使用说明：
 * 1. 在云开发控制台中选择 "云函数" -> "quickstartFunctions" -> "测试"
 * 2. 在测试参数中输入：{"type": "addFirstAdmin", "adminOpenid": "oQHcB7B-lcSlMH5g3tJrqdxR1VUQ"}
 * 3. 点击 "运行测试" 按钮，即可添加管理员
 * 4. 添加完成后，建议删除或注释掉此函数，以保证系统安全
 */

/**
 * 添加第一个管理员账号（绕过权限检查）
 * @param {Object} event 包含adminOpenid的参数
 * @returns {Promise<{success: boolean, message?: string, errMsg?: string}>} 添加结果
 */
const addFirstAdmin = async (event) => {
  try {
    console.log('addFirstAdmin函数开始执行 - 注意：这是一个临时的权限绕过函数');
    console.log('警告：添加完成后应删除此函数以保证系统安全');
    
    const { adminOpenid } = event;
    if (!adminOpenid) {
      return {
        success: false,
        errMsg: '缺少管理员openid'
      };
    }
    
    // 检查管理员是否已存在
    const { data: admins } = await db.collection('admins').where({
      openid: adminOpenid
    }).get();
    
    if (admins.length > 0) {
      return {
        success: false,
        errMsg: '该账号已为管理员'
      };
    }
    
    // 添加管理员
    await db.collection('admins').add({
      data: {
        openid: adminOpenid,
        createTime: db.serverDate()
      }
    });
    
    console.log(`管理员添加成功，openid: ${adminOpenid}`);
    return {
      success: true,
      message: '管理员添加成功（通过临时权限绕过函数）'
    };
  } catch (error) {
    console.error('添加管理员失败:', error);
    return {
      success: false,
      errMsg: `添加管理员失败：${error.message || '未知错误'}`
    };
  }
};

// 需要将此函数导出并在main函数中注册
// 由于此文件是辅助文件，实际使用时需要将函数添加到index.js中
console.log('第一个管理员添加工具已加载，请按照注释中的步骤操作');
console.log('重要提醒：完成添加后，请删除此函数以保证系统安全');

// 导出函数，便于在index.js中引用
module.exports = addFirstAdmin;