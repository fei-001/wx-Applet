Page({
  data: {
    messageList: [],
    isLoading: false
  },

  // 格式化时间
  formatTime(time) {
    if (!time) return '';
    
    const date = new Date(time);
    const now = new Date();
    const diffInDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
    
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    
    if (diffInDays === 0) {
      // 今天的消息，只显示时间
      return `${hours}:${minutes}`;
    } else if (diffInDays === 1) {
      // 昨天的消息
      return `昨天 ${hours}:${minutes}`;
    } else if (diffInDays < 7) {
      // 一周内的消息
      const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
      return `${weekdays[date.getDay()]} ${hours}:${minutes}`;
    } else {
      // 更早的消息，显示完整日期
      const year = date.getFullYear();
      return `${year}-${month}-${day} ${hours}:${minutes}`;
    }
  },
  
  // 根据消息标题获取状态类名
  getStatusClass(title) {
    if (title.includes('已被接收')) {
      return 'accepted';
    } else if (title.includes('已完成')) {
      return 'completed';
    } else if (title.includes('已取消')) {
      return 'cancelled';
    } else if (title.includes('已被拒绝')) {
      return 'rejected';
    }
    return '';
  },
  
  // 根据消息标题获取状态文本
  getStatusText(title) {
    if (title.includes('已被接收')) {
      return '处理中';
    } else if (title.includes('已完成')) {
      return '已完成';
    } else if (title.includes('已取消')) {
      return '已取消';
    } else if (title.includes('已被拒绝')) {
      return '已拒绝';
    }
    return '';
  },

  onLoad() {
    // 页面加载时显示骨架屏效果
    this.setData({ isLoading: true });
    // 模拟网络延迟，提升用户体验
    setTimeout(() => {
      this.getNotificationList();
    }, 300);
  },

  onShow() {
    // 页面显示时检查是否需要清理旧记录
    this.checkAndCleanupOldRecords();
    
    // 页面显示时重新获取消息列表，确保数据最新
    if (!this.data.isLoading) {
      this.setData({ isLoading: true });
      setTimeout(() => {
        this.getNotificationList();
      }, 300);
    }
  },
  
  // 检查并清理旧记录（每24小时最多清理一次）
  checkAndCleanupOldRecords() {
    const lastCleanupTime = wx.getStorageSync('lastCleanupTime') || 0;
    const now = Date.now();
    const oneDayInMs = 24 * 60 * 60 * 1000;
    
    // 如果距离上次清理超过1天，则执行清理
    if (now - lastCleanupTime > oneDayInMs) {
      console.log('触发定期清理操作');
      this.cleanupOldRecords();
      wx.setStorageSync('lastCleanupTime', now);
    }
  },
  
  // 调用云函数清理旧记录
  cleanupOldRecords() {
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'cleanupOldRecords'
      },
      success: res => {
        console.log('清理旧记录结果:', res.result);
        // 清理操作是后台任务，不需要向用户展示结果
      },
      fail: err => {
        console.error('清理旧记录失败:', err);
        // 清理失败不影响用户使用，记录错误即可
      }
    });
  },

  // 获取消息列表并关联订单详情
  getNotificationList() {
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo || !userInfo._id) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    this.setData({ isLoading: true });

    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getNotifications',
        userId: userInfo._id
      },
      success: (res) => {
        console.log('获取消息列表结果:', res.result);
        if (res.result && res.result.success) {
          const messageList = res.result.data || [];
          // 为每条消息获取对应的订单详情
          this.enrichMessagesWithOrderDetails(messageList);
        } else {
          wx.showToast({ title: '获取消息失败', icon: 'none' });
          this.setData({ isLoading: false });
        }
      },
      fail: (err) => {
        console.error('获取消息列表失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
        this.setData({ isLoading: false });
      }
    });
  },

  // 为消息添加订单详情信息（如取件码）
  enrichMessagesWithOrderDetails(messageList) {
    if (!messageList || messageList.length === 0) {
      this.setData({
        messageList: [],
        isLoading: false
      });
      this.markAllMessagesAsRead();
      return;
    }

    // 获取所有订单ID
    const orderIds = [...new Set(messageList.map(msg => msg.orderId).filter(id => id))];
    
    if (orderIds.length === 0) {
      // 即使没有订单ID，也按消息创建时间排序
      const sortedMessages = messageList.sort((a, b) => {
        return new Date(b.createTime || 0) - new Date(a.createTime || 0);
      });
      
      this.setData({
        messageList: sortedMessages,
        isLoading: false
      });
      this.markAllMessagesAsRead();
      return;
    }

    // 批量获取订单详情
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getOrdersByIds',
        orderIds: orderIds
      },
      success: (res) => {
        console.log('获取订单详情结果:', res.result);
        const orderMap = {};
        
        if (res.result && res.result.success && res.result.data) {
          // 创建订单ID到订单详情的映射
          res.result.data.forEach(order => {
            orderMap[order._id] = order;
          });
        }

        // 为每条消息添加订单详情
        const enrichedMessages = messageList.map(msg => ({
          ...msg,
          orderDetails: orderMap[msg.orderId] || null
        }));

        // 按订单下单时间排序（从最新到最旧）
        const sortedMessages = enrichedMessages.sort((a, b) => {
          // 优先按订单下单时间排序，如果没有订单详情则按消息创建时间排序
          const timeA = a.orderDetails && a.orderDetails.createTime ? new Date(a.orderDetails.createTime) : new Date(a.createTime || 0);
          const timeB = b.orderDetails && b.orderDetails.createTime ? new Date(b.orderDetails.createTime) : new Date(b.createTime || 0);
          return timeB - timeA;
        });

        this.setData({
          messageList: sortedMessages
        });
        this.markAllMessagesAsRead();
      },
      fail: (err) => {
        console.error('获取订单详情失败:', err);
        // 即使获取订单详情失败，也显示消息列表并按消息创建时间排序
        const sortedMessages = messageList.sort((a, b) => {
          return new Date(b.createTime || 0) - new Date(a.createTime || 0);
        });
        
        this.setData({
          messageList: sortedMessages
        });
        this.markAllMessagesAsRead();
      },
      complete: () => {
        this.setData({ isLoading: false });
      }
    });
  },

  // 标记所有消息为已读
  markAllMessagesAsRead() {
    const unreadMessages = this.data.messageList.filter(item => !item.isRead);
    if (unreadMessages.length === 0) return;

    unreadMessages.forEach(message => {
      wx.cloud.callFunction({
        name: 'quickstartFunctions',
        data: {
          type: 'markNotificationAsRead',
          notificationId: message._id
        },
        success: (res) => {
          console.log('标记消息为已读成功:', message._id);
        },
        fail: (err) => {
          console.error('标记消息为已读失败:', err);
        }
      });
    });
  },

  // 点击消息查看订单详情
  onMessageTap(e) {
    const { orderId } = e.currentTarget.dataset;
    if (orderId) {
      wx.navigateTo({
        url: `/pages/order/order?orderId=${orderId}&scrollToOrder=true`
      });
    }
  },
  
  // 长按消息删除记录
  onMessageLongPress(e) {
    const { messageId } = e.currentTarget.dataset;
    
    // 显示确认对话框
    wx.showModal({
      title: '删除确认',
      content: '确定要删除这条消息吗？',
      success: (res) => {
        if (res.confirm) {
          // 用户确认删除，从本地列表中移除
          const messageList = this.data.messageList.filter(item => item._id !== messageId);
          this.setData({ messageList });
          
          // 调用云函数从数据库中删除
          this.deleteMessageFromDatabase(messageId);
          
          // 如果删除后没有消息了，更新加载状态
          if (messageList.length === 0) {
            this.setData({ isLoading: false });
          }
        }
      }
    });
  },
  
  // 从数据库中删除消息记录
  deleteMessageFromDatabase(messageId) {
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'deleteNotification',
        notificationId: messageId
      },
      success: (res) => {
        console.log('删除消息成功:', res.result);
      },
      fail: (err) => {
        console.error('删除消息失败:', err);
        // 即使删除失败，本地也已移除，不影响用户体验
      }
    });
  },

  // 返回上一页
  onBackTap() {
    wx.navigateBack();
  }
});