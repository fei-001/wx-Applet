Page({
  filters: {
    formatExpressType: function(type) {
      const typeMap = {
        '菜鸟驿站': '菜鸟驿站',
        '申通': '申通',
        '顺丰': '顺丰',
        '其他': '其他'
      };
      return typeMap[type] || '未知类型';
    }
  },
  
  data: {
    orders: []
  },

  onLoad(options) {
    this.setData({
      targetOrderId: options.orderId || '',
      scrollToOrder: options.scrollToOrder === 'true'
    });
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    // 使用用户的 _id 获取订单
    this.getOrders(userInfo._id);
  },

  onShow() {
    // 页面显示时检查是否需要清理旧记录
    this.checkAndCleanupOldRecords();
    
    // 页面显示时重新获取订单，确保数据最新
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.getOrders(userInfo._id);
    }
  },
  
  // 检查并清理旧记录（每24小时最多清理一次）
  checkAndCleanupOldRecords() {
    const lastCleanupTime = wx.getStorageSync('lastCleanupTime') || 0;
    const now = Date.now();
    const oneDayInMs = 24 * 60 * 60 * 1000;
    
    // 如果距离上次清理超过1天，则执行清理
    if (now - lastCleanupTime > oneDayInMs) {
      console.log('触发定期清理操作');
      this.cleanupOldRecords();
      wx.setStorageSync('lastCleanupTime', now);
    }
  },
  
  // 调用云函数清理旧记录
  cleanupOldRecords() {
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'cleanupOldRecords'
      },
      success: res => {
        console.log('清理旧记录结果:', res.result);
        // 清理操作是后台任务，不需要向用户展示结果
      },
      fail: err => {
        console.error('清理旧记录失败:', err);
        // 清理失败不影响用户使用，记录错误即可
      }
    });
  },

  // 滚动到指定订单
  scrollToOrder(orderId) {
    const query = wx.createSelectorQuery();
    query.select(`#order-item-${orderId}`).boundingClientRect();
    query.selectViewport().scrollOffset();
    query.exec((res) => {
      if (res[0] && res[1]) {
        wx.pageScrollTo({
          scrollTop: res[1].scrollTop + res[0].top - 100,
          duration: 300
        });
      }
    });
  },

  // 处理订单点击事件
  onOrderItemTap(e) {
    const orderId = e.currentTarget.dataset.orderId;
    const orderStatus = e.currentTarget.dataset.orderStatus;
    
    // 只处理接单中和完成状态的订单
    if (orderStatus === 'processing' || orderStatus === 'completed') {
      // 查找对应的订单数据
      const order = this.data.orders.find(item => item._id === orderId);
      if (order) {
        // 获取代取手信息
        const courierName = order.courierName || '暂无姓名信息';
        const courierPhone = order.courierPhone || '暂无电话信息';
        const pickupTime = order.pickupTime ? this.formatTime(order.pickupTime) : '暂无接单时间';
        
        // 显示代取手信息
        wx.showModal({
          title: '接单人员信息',
          content: `姓名：${courierName}\n电话：${courierPhone}\n接单时间：${pickupTime}`,
          showCancel: false,
          confirmText: '我知道了'
        });
      } else {
        wx.showToast({ title: '未找到订单信息', icon: 'none' });
      }
    }
  },
  
  // 格式化时间
  formatTime(time) {
    if (typeof time === 'string') {
      return time;
    } else if (time && time._seconds) {
      // 处理云开发的时间对象格式
      const date = new Date(time._seconds * 1000);
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    } else if (time instanceof Date) {
      return `${time.getFullYear()}-${String(time.getMonth() + 1).padStart(2, '0')}-${String(time.getDate()).padStart(2, '0')} ${String(time.getHours()).padStart(2, '0')}:${String(time.getMinutes()).padStart(2, '0')}`;
    }
    return '暂无时间信息';
  },
  
  getOrders(userId) {
    console.log('开始获取订单，用户ID:', userId);
    wx.cloud.callFunction({ 
      name: 'quickstartFunctions',
      data: {
        type: 'getOrders',
        userId: userId
      },
      success: res => {
        console.log('云函数返回结果:', JSON.stringify(res));
        if (res.result.success) {
          console.log('获取到的原始订单数据：', JSON.stringify(res.result.data));
          
          // 打印所有订单的createTime详情，用于调试
          if (res.result.data && res.result.data.length > 0) {
            res.result.data.forEach((order, index) => {
              console.log(`订单${index + 1}的createTime类型:`, typeof order.createTime);
              console.log(`订单${index + 1}的createTime值:`, order.createTime);
              if (typeof order.createTime === 'object') {
                console.log(`订单${index + 1}的createTime对象结构:`, JSON.stringify(order.createTime));
              }
            });
          }
          
          // 处理订单数据，设置默认状态和转换类型
          const orders = res.result.data.map(item => {
            // 设置默认状态为未接单
            if (!item.status) {
              item.status = 'pending';
            }
            // 将expressType转换为字符串
            if (item.expressType !== undefined) {
              item.expressType = String(item.expressType);
            }
            // 确保createTime字段存在且格式正确
            if (item.createTime) {
              // 微信小程序云开发返回的Date类型可能被包装在对象中
              if (typeof item.createTime === 'object' && item.createTime._seconds) {
                // 处理云开发的时间对象格式
                console.log('处理云开发时间对象:', item.createTime);
                item.createTime = new Date(item.createTime._seconds * 1000);
              } else if (typeof item.createTime === 'string') {
                // 处理字符串形式的时间
                console.log('处理字符串时间:', item.createTime);
                item.createTime = new Date(item.createTime);
              } else if (typeof item.createTime === 'number') {
                // 处理数字形式的时间戳
                console.log('处理时间戳:', item.createTime);
                item.createTime = new Date(item.createTime);
              } else if (item.createTime instanceof Date) {
                console.log('已经是Date对象:', item.createTime);
              } else {
                console.log('未知时间格式，直接转换:', item.createTime);
                item.createTime = new Date(item.createTime);
              }
              // 验证时间是否有效
              if (isNaN(item.createTime.getTime())) {
                console.warn('无效的时间格式，使用当前时间替代:', item.createTime);
                item.createTime = new Date();
              }
              // 添加格式化后的时间字符串，直接用于显示
              item.formattedCreateTime = `${item.createTime.getFullYear()}-${String(item.createTime.getMonth() + 1).padStart(2, '0')}-${String(item.createTime.getDate()).padStart(2, '0')} ${String(item.createTime.getHours()).padStart(2, '0')}:${String(item.createTime.getMinutes()).padStart(2, '0')}`;
              console.log('格式化后的时间:', item.formattedCreateTime);
            } else {
              // 如果没有createTime，设置默认时间
              item.createTime = new Date();
              item.formattedCreateTime = `${item.createTime.getFullYear()}-${String(item.createTime.getMonth() + 1).padStart(2, '0')}-${String(item.createTime.getDate()).padStart(2, '0')} ${String(item.createTime.getHours()).padStart(2, '0')}:${String(item.createTime.getMinutes()).padStart(2, '0')}`;
              console.warn('订单缺少createTime字段，使用当前时间替代');
            }
            return item;
          });
          
          // 按创建时间从新到旧排序订单
          orders.sort((a, b) => {
            return b.createTime - a.createTime;
          });
          console.log('排序后的订单数据:', JSON.stringify(orders));
          this.setData({ orders });

          // 如果需要滚动到指定订单，延迟执行滚动操作
          if (this.data.scrollToOrder && this.data.targetOrderId) {
            setTimeout(() => {
              this.scrollToOrder(this.data.targetOrderId);
            }, 500);
          }
        } else {
          console.error('获取订单失败:', res.result.errMsg);
          wx.showToast({ title: '获取订单失败：' + (res.result.errMsg || '未知错误'), icon: 'none' });
        }
      },
      fail: err => {
        console.error('云函数调用失败', err);
        wx.showToast({ title: '网络错误，请重试', icon: 'none' });
      }
    });
  }
})