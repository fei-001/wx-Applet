Page({
  data: {
    errandList: [],
    isLoading: false,
    searchKey: '',
    filterStatus: 'all', // all, pending, accepted, processing, completed, cancelled
    currentPage: 1,
    pageSize: 20,
    hasMore: true
  },

  onLoad() {
    this.checkAdminPermission();
    this.getErrandList();
  },

  // 检查管理员权限
  checkAdminPermission() {
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkAdmin'
      },
      success: (res) => {
        const isAdmin = res.result && res.result.success && res.result.isAdmin;
        if (!isAdmin) {
          wx.showToast({ title: '您不是管理员，无法访问', icon: 'none' });
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        }
      },
      fail: (err) => {
        console.error('检查管理员权限失败:', err);
        wx.showToast({ title: '权限验证失败', icon: 'none' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      }
    });
  },

  // 获取跑腿任务列表
  getErrandList() {
    if (this.data.isLoading || !this.data.hasMore) return;
    
    this.setData({ isLoading: true });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getErrandTasks',
        searchKey: this.data.searchKey,
        status: this.data.filterStatus,
        page: this.data.currentPage,
        pageSize: this.data.pageSize
      },
      success: (res) => {
        if (res.result && res.result.success) {
          const newErrands = res.result.data || [];
          const updatedList = this.data.currentPage === 1 ? newErrands : [...this.data.errandList, ...newErrands];
          
          this.setData({
            errandList: updatedList,
            hasMore: newErrands.length === this.data.pageSize,
            currentPage: this.data.currentPage + 1
          });
        } else {
          wx.showToast({ title: '获取跑腿任务失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('获取跑腿任务失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        this.setData({ isLoading: false });
      }
    });
  },

  // 搜索跑腿任务
  onSearch(e) {
    const { value } = e.detail;
    this.setData({
      searchKey: value,
      currentPage: 1,
      hasMore: true
    }, () => {
      this.getErrandList();
    });
  },

  // 切换筛选状态
  onFilterChange(e) {
    const { status } = e.currentTarget.dataset;
    this.setData({
      filterStatus: status,
      currentPage: 1,
      hasMore: true
    }, () => {
      this.getErrandList();
    });
  },

  // 更新任务状态
  updateErrandStatus(e) {
    const { taskId, status } = e.currentTarget.dataset;
    
    let confirmContent = '';
    switch(status) {
      case 'accepted':
        confirmContent = '确定要接单此跑腿任务吗？';
        break;
      case 'processing':
        confirmContent = '确定要开始处理此跑腿任务吗？';
        break;
      case 'completed':
        confirmContent = '确定要标记此跑腿任务为已完成吗？';
        break;
      case 'cancelled':
        confirmContent = '确定要取消此跑腿任务吗？';
        break;
      default:
        confirmContent = '确定要执行此操作吗？';
    }
    
    wx.showModal({
      title: '确认操作',
      content: confirmContent,
      success: (res) => {
        if (res.confirm) {
          this.submitErrandStatusUpdate(taskId, status);
        }
      }
    });
  },

  // 提交状态更新
  submitErrandStatusUpdate(taskId, status) {
    wx.showLoading({ title: '处理中...' });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'updateErrandTaskStatus',
        taskId: taskId,
        status: status
      },
      success: (res) => {
        if (res.result && res.result.success) {
          wx.showToast({ title: '操作成功', icon: 'success' });
          // 刷新列表
          this.setData({ currentPage: 1, hasMore: true }, () => {
            this.getErrandList();
          });
        } else {
          wx.showToast({ title: '操作失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('更新任务状态失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },

  // 查看任务详情
  onErrandDetail(e) {
    const { errand } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/errand-detail/errand-detail?taskId=${errand._id}`
    });
  },

  // 添加新跑腿任务
  onAddErrand() {
    wx.navigateTo({
      url: '/pages/add-errand/add-errand'
    });
  },

  // 上拉加载更多
  onReachBottom() {
    this.getErrandList();
  },

  // 返回上一页
  onBackTap() {
    wx.navigateBack();
  }
});