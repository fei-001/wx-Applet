Page({
  data: {
    currentCategory: '餐饮代取',
    selectedTab: 'service'
  },
  onLoad() {
    // 页面加载时初始化分类状态
  },
  onShow() {
    // 页面显示时更新导航状态
  },
  switchCategory(e) {
    const { category } = e.currentTarget.dataset;
    this.setData({ currentCategory: category });
  }
})