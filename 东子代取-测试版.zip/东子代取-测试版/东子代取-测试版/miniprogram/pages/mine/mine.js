Page({
  data: {
    selectedTab: 'mine',
    userInfo: null,
    isAdmin: false,
    isCourier: false,
    unreadCount: 0
  },

  onLoad() {
    // 页面加载时初始化数据
  },

  onShow() {
    // 页面显示时从本地存储获取用户信息并更新UI
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      console.log('mine页面获取到的用户信息:', userInfo);
      this.setData({ userInfo });
      // 检查是否为管理员
      this.checkAdminPermission();
      // 检查是否为代取手
      this.checkCourierStatus();
      // 获取未读消息数量
      this.getUnreadMessageCount();
    }
  },

  // 检查是否为管理员
  checkAdminPermission() {
    const userInfo = this.data.userInfo;
    if (!userInfo) return;

    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkAdmin'
      },
      success: (res) => {
        console.log('管理员权限检查结果:', res.result);
        if (res.result && res.result.success) {
          this.setData({
            isAdmin: res.result.isAdmin
          });
        }
      },
      fail: (err) => {
        console.error('检查管理员权限失败:', err);
      }
    });
  },

  // 检查是否为代取手
  checkCourierStatus() {
    const userInfo = this.data.userInfo;
    if (!userInfo) {
      console.log('未找到用户信息，重置代取手状态');
      this.setData({ isCourier: false });
      return;
    }

    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkCourierStatus'
      },
      success: (res) => {
        console.log('代取手身份检查结果:', res.result);
        if (res.result && res.result.success) {
          this.setData({
            isCourier: res.result.isCourier
          });
          console.log(`代取手状态更新为: ${res.result.isCourier}`);
        } else {
          console.warn('代取手身份检查结果异常，重置状态:', res.result);
          this.setData({ isCourier: false });
        }
      },
      fail: (err) => {
        console.error('检查代取手身份失败:', err);
        // 失败时重置代取手状态
        this.setData({ isCourier: false });
      }
    });
  },

  // 获取未读消息数量
  getUnreadMessageCount() {
    const userInfo = this.data.userInfo;
    if (!userInfo || !userInfo._id) return;

    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getNotifications',
        userId: userInfo._id
      },
      success: (res) => {
        console.log('获取消息列表结果:', res.result);
        if (res.result && res.result.success && res.result.data) {
          // 计算未读消息数量
          const unreadCount = res.result.data.filter(item => !item.isRead).length;
          this.setData({
            unreadCount: unreadCount
          });
        }
      },
      fail: (err) => {
        console.error('获取消息列表失败:', err);
      }
    });
  },

  onLoginTap() {
    if (this.data.userInfo) {
      wx.showToast({ title: '您已登录，无需重复登录', icon: 'none' });
      return;
    }
    wx.navigateTo({
      url: '/pages/login/login'
    });
  },

  onAvatarTap() {
    if (this.data.userInfo) {
      wx.showToast({ title: '您已登录，无需重复登录', icon: 'none' });
      return;
    }
    // 跳转至登录页面
    wx.navigateTo({
      url: '/pages/login/login'
    });
  },

  onLogoutTap() {
    // 清除本地存储的用户信息
    wx.removeStorageSync('userInfo');
    // 更新页面状态
    this.setData({
      userInfo: null,
      isAdmin: false,
      unreadCount: 0
    });
    wx.showToast({
      title: '退出登录成功',
      icon: 'success',
      duration: 1500
    });
  },

  // 查看订单列表
  onOrderListTap() {
    if (!this.data.userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    wx.navigateTo({
      url: '/pages/order/order'
    });
  },

  // 查看消息列表
  onMessageListTap() {
    if (!this.data.userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    wx.navigateTo({
      url: '/pages/message/message'
    });
  },

  // 进入管理页面
  onAdminTap() {
    if (!this.data.userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    wx.navigateTo({
      url: '/pages/admin-dashboard/admin-dashboard'
    });
  },

  // 进入接取订单页面
  onCourierOrderTap() {
    console.log('接取订单按钮被点击，isCourier:', this.data.isCourier, 'userInfo:', !!this.data.userInfo);
    if (!this.data.userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    
    // 跳转到管理端的订单管理页面
    const targetUrl = '/pages/admin/admin';
    const targetPageName = '管理端订单管理页面';
    
    wx.navigateTo({
      url: targetUrl,
      success: function(res) {
        console.log(`成功跳转到${targetPageName}`);
      },
      fail: function(err) {
        console.error(`跳转到${targetPageName}失败:`, err);
        wx.showToast({ title: '跳转失败，请重试', icon: 'none' });
      }
    });
  },
});