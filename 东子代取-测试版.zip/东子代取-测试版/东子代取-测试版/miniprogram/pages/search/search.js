// 搜索页面，用于按取件码搜索订单
Page({
  data: {
    searchCode: '', // 搜索框输入的取件码
    orderInfo: null, // 搜索到的订单信息
    errorMsg: '', // 错误信息
    loading: false // 加载状态
  },

  // 监听输入框变化
  onInput(e) {
    this.setData({
      searchCode: e.detail.value
    });
  },

  // 执行搜索
  searchOrder() {
    const { searchCode } = this.data;
    
    // 输入验证
    if (!searchCode.trim()) {
      this.setData({
        errorMsg: '请输入取件码',
        orderInfo: null
      });
      return;
    }

    // 显示加载状态
    this.setData({
      loading: true,
      errorMsg: '',
      orderInfo: null
    });

    // 调用云函数搜索订单
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getOrdersByCode',
        code: searchCode
      }
    }).then(res => {
      this.setData({ loading: false });
      
      if (res.result && res.result.data && res.result.data.length > 0) {
        // 找到订单，显示订单信息
        this.setData({
          orderInfo: res.result.data[0]
        });
      } else {
        // 未找到订单
        this.setData({
          errorMsg: '未找到该取件码对应的订单',
          orderInfo: null
        });
      }
    }).catch(err => {
      console.error('搜索订单失败', err);
      this.setData({
        loading: false,
        errorMsg: '搜索失败，请重试',
        orderInfo: null
      });
    });
  },

  // 处理返回按钮点击
  onBackPress() {
    wx.navigateBack();
  },

  // 查看订单详情
  onOrderDetail(e) {
    const orderId = e.currentTarget.dataset.id || this.data.orderInfo._id;
    wx.navigateTo({
      url: `/pages/order/order?orderId=${orderId}&scrollToOrder=true`
    });
  },
  
  // 获取订单状态对应的文本
  getStatusText(status) {
    const statusMap = {
      pending: '待处理',
      processing: '处理中',
      completed: '已完成',
      canceled: '已取消'
    };
    return statusMap[status] || '未知状态';
  },
  
  // 获取订单状态对应的CSS类
  getStatusClass(status) {
    return `order-status status-${status}`;
  }
});