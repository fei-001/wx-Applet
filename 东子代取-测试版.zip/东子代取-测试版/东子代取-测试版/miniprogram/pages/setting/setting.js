Page({
  data: {
    infoList: [
      { name: '', phone: '', address: '' },
      { name: '', phone: '', address: '' },
      { name: '', phone: '', address: '' }
    ],
    currentInfoIndex: 0 // 默认使用取件信息1
  },

  onLoad() {
    // 页面加载时，从本地存储读取取件信息
    this.loadInfoFromStorage();
  },

  onShow() {
    // 页面显示时，再次读取数据，确保与最新状态同步
    this.loadInfoFromStorage();
  },

  // 从本地存储加载取件信息
  loadInfoFromStorage() {
    try {
      // 读取取件信息列表
      const savedInfoList = wx.getStorageSync('pickupInfoList');
      if (savedInfoList) {
        this.setData({
          infoList: JSON.parse(savedInfoList)
        });
      }

      // 读取默认信息索引
      const savedCurrentIndex = wx.getStorageSync('currentPickupInfoIndex');
      if (savedCurrentIndex !== '') {
        this.setData({
          currentInfoIndex: savedCurrentIndex
        });
      }
    } catch (e) {
      console.error('读取取件信息失败:', e);
    }
  },

  // 处理姓名输入
  onNameInput(e) {
    const { index } = e.currentTarget.dataset;
    const name = e.detail.value.trim();
    const infoList = this.data.infoList;
    infoList[index].name = name;
    this.setData({ infoList });
  },

  // 处理电话输入
  onPhoneInput(e) {
    const { index } = e.currentTarget.dataset;
    const phone = e.detail.value;
    const infoList = this.data.infoList;
    infoList[index].phone = phone;
    this.setData({ infoList });
  },

  // 处理地址输入
  onAddressInput(e) {
    const { index } = e.currentTarget.dataset;
    const address = e.detail.value.trim();
    const infoList = this.data.infoList;
    infoList[index].address = address;
    this.setData({ infoList });
  },

  // 保存取件信息
  onSaveInfo(e) {
    const { index } = e.currentTarget.dataset;
    const info = this.data.infoList[index];

    // 验证信息
    if (!info.name) {
      wx.showToast({ title: '请输入取件人姓名', icon: 'none' });
      return;
    }
    if (!info.phone) {
      wx.showToast({ title: '请输入取件人电话', icon: 'none' });
      return;
    }
    if (!/^1[3-9]\d{9}$/.test(info.phone)) {
      wx.showToast({ title: '请输入有效的11位手机号码', icon: 'none' });
      return;
    }
    if (!info.address) {
      wx.showToast({ title: '请输入收货地址', icon: 'none' });
      return;
    }

    try {
      // 保存到本地存储
      wx.setStorageSync('pickupInfoList', JSON.stringify(this.data.infoList));
      wx.showToast({ title: '保存成功', icon: 'success' });
    } catch (e) {
      console.error('保存取件信息失败:', e);
      wx.showToast({ title: '保存失败，请重试', icon: 'none' });
    }
  },

  // 设置默认取件信息
  onSetDefault(e) {
    const { index } = e.currentTarget.dataset;
    const info = this.data.infoList[index];

    // 检查该信息是否已填写完整
    if (!info.name || !info.phone || !info.address) {
      wx.showToast({ title: '请先完善取件信息', icon: 'none' });
      return;
    }

    try {
      // 保存默认索引到本地存储
      wx.setStorageSync('currentPickupInfoIndex', index);
      this.setData({
        currentInfoIndex: index
      });
      wx.showToast({ title: '已设为默认', icon: 'success' });
    } catch (e) {
      console.error('设置默认信息失败:', e);
      wx.showToast({ title: '设置失败，请重试', icon: 'none' });
    }
  },

  // 返回上一页
  onBackTap() {
    wx.navigateBack();
  }
});