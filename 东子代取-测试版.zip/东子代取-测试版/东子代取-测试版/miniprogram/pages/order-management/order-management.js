Page({
  data: {
    tabs: [
      { id: 'pending', name: '待处理' },
      { id: 'processing', name: '处理中' },
      { id: 'completed', name: '已完成' }
    ],
    activeTab: 'pending',
    orderList: [],
    classifiedOrders: {},
    currentPage: 1,
    pageSize: 10,
    hasMore: true,
    isLoading: false,
    userInfo: null,
    showDebugInfo: true, // 默认显示调试信息
    orderDebugInfo: '' // 存储调试信息
  },

  onLoad() {
    // 从本地存储获取用户信息
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({ userInfo });
    }
    this.checkAccessPermission();
    // 不再单独调用getOrderList，而是在checkAccessPermission中根据权限结果来决定是否加载订单
  },

  onShow() {
    // 页面显示时重新获取用户信息
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({ userInfo });
    }
  },

  // 检查访问权限 - 管理员或代取手都可访问
  checkAccessPermission() {
    const checkAdmin = new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'quickstartFunctions',
        data: { type: 'checkAdmin' },
        success: (res) => {
          resolve(res.result && res.result.success && res.result.isAdmin);
        },
        fail: () => resolve(false)
      });
    });

    const checkCourier = new Promise((resolve, reject) => {
      wx.cloud.callFunction({
        name: 'quickstartFunctions',
        data: { type: 'checkCourierStatus' },
        success: (res) => {
          resolve(res.result && res.result.success && res.result.isCourier);
        },
        fail: () => resolve(false)
      });
    });

    Promise.all([checkAdmin, checkCourier]).then(([isAdmin, isCourier]) => {
      console.log('订单管理页面权限检查结果：isAdmin=', isAdmin, 'isCourier=', isCourier);
      if (!isAdmin && !isCourier) {
        wx.showToast({ title: '您没有权限访问此页面', icon: 'none' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        // 有权限，确保正确加载订单
        this.getOrderList();
      }
    }).catch((err) => {
      console.error('权限验证失败:', err);
      wx.showToast({ title: '权限验证失败', icon: 'none' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    });
  },

  // 获取订单列表
  getOrderList() {
    console.log('开始获取订单列表，当前标签:', this.data.activeTab);
    
    if (this.data.isLoading) {
      console.log('已有请求在处理中，忽略重复请求');
      return;
    }
    
    this.setData({ isLoading: true });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getAllOrders', // 使用已实现的getAllOrders云函数
        status: this.data.activeTab
      },
      success: (res) => {
        console.log('获取订单列表结果:', res.result);
        if (res.result && res.result.success) {
          const newOrders = res.result.data || [];
          
          // 格式化接单时间并确保代取手信息字段存在
          const formattedOrders = newOrders.map(order => {
            // 确保代取手相关字段存在并有默认值，同时支持驼峰命名和下划线命名格式
            const formattedOrder = {
              ...order,
              courierName: order.courierName || order.courier_name || '未分配',
              courierPhone: order.courierPhone || order.courier_phone || '未提供',
              courierId: order.courierId || order.courier_id || ''
            };
            
            // 格式化接单时间
            if (formattedOrder.pickupTime) {
              try {
                const date = new Date(formattedOrder.pickupTime);
                const year = date.getFullYear();
                const month = (date.getMonth() + 1).toString().padStart(2, '0');
                const day = date.getDate().toString().padStart(2, '0');
                const hours = date.getHours().toString().padStart(2, '0');
                const minutes = date.getMinutes().toString().padStart(2, '0');
                formattedOrder.pickupTime = `${year}-${month}-${day} ${hours}:${minutes}`;
              } catch (e) {
                console.error('格式化接单时间失败:', e);
              }
            }
            
            return formattedOrder;
          });
          
          // 按快递类型分类订单
          const classifiedOrders = this.classifyOrdersByExpressType(formattedOrders);
          
          // 设置调试信息，显示第一笔订单的完整数据结构
          let debugInfo = '暂无订单数据';
          if (formattedOrders.length > 0) {
            const firstOrder = formattedOrders[0];
            // 单独显示代取手信息部分
            const courierInfo = '代取手信息：\n姓名: ' + (firstOrder.courierName || '未分配') + '\n手机号: ' + (firstOrder.courierPhone || '未提供') + '\nID: ' + (firstOrder.courierId || '无') + '\n接单时间: ' + (firstOrder.pickupTime || '无');
            
            debugInfo = '订单总数: ' + formattedOrders.length + '\n\n第一笔订单详情：\n' + JSON.stringify(firstOrder, null, 2) + '\n\n' + courierInfo;
          }
            
          this.setData({
            orderList: formattedOrders,
            classifiedOrders: classifiedOrders,
            hasMore: false, // getAllOrders返回所有数据，不需要分页
            currentPage: 1,
            orderDebugInfo: debugInfo
          });
        } else {
          wx.showToast({ title: '获取订单列表失败', icon: 'none' });
          console.error('获取订单列表失败:', res);
        }
      },
      fail: (err) => {
        console.error('获取订单列表失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        this.setData({ isLoading: false });
      }
    });
  },

  // 按快递类型分类订单
  classifyOrdersByExpressType(orders) {
    const classified = {};
    
    orders.forEach(order => {
      // 确保expressType存在并有默认值
      const expressType = order.expressType || '其他';
      if (!classified[expressType]) {
        classified[expressType] = [];
      }
      
      // 确保订单对象完整，包含所有必要字段
      const orderWithDefaults = {
        ...order,
        id: order.id || '',
        expressType: expressType,
        status: order.status || 'pending',
        createTime: order.createTime || '',
        location: order.location || '',
        remarks: order.remarks || '',
        // 代取手信息字段默认值
        courierName: order.courierName || '未分配',
        courierPhone: order.courierPhone || '未提供',
        courierId: order.courierId || '',
        pickupTime: order.pickupTime || ''
      };
      
      classified[expressType].push(orderWithDefaults);
    });
    
    return classified;
  },

  // 标签页切换
  onTabChange(e) {
    const { tabId } = e.currentTarget.dataset;
    this.setData({
      activeTab: tabId,
      orderList: [],
      classifiedOrders: {},
      currentPage: 1,
      hasMore: true
    }, () => {
      this.getOrderList();
    });
  },

  // 接单
  acceptOrder(e) {
    const { orderId } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '确认接单',
      content: '确定要接受此订单吗？',
      success: (res) => {
        if (res.confirm) {
          this.updateOrderStatus(orderId, 'processing');
        }
      }
    });
  },

  // 拒绝订单
  rejectOrder(e) {
    const { orderId } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '拒绝订单',
      content: '确定要拒绝此订单吗？',
      success: (res) => {
        if (res.confirm) {
          this.updateOrderStatus(orderId, 'cancelled');
        }
      }
    });
  },

  // 完成订单
  completeOrder(e) {
    const { orderId } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '完成订单',
      content: '确定此订单已完成吗？',
      success: (res) => {
        if (res.confirm) {
          this.updateOrderStatus(orderId, 'completed');
        }
      }
    });
  },

  // 更新订单状态
  updateOrderStatus(orderId, status) {
    wx.showLoading({ title: '处理中...' });
    
    // 构造请求数据
    const requestData = {
      type: 'updateOrderStatus',
      orderId: orderId,
      status: status
    };
    
    // 当接单时(status为processing)，添加代取手信息
    if (status === 'processing' && this.data.userInfo && this.data.userInfo._id) {
      requestData.courierId = this.data.userInfo._id;
      requestData.courierName = this.data.userInfo.nickName || '代取手';
      requestData.courierPhone = this.data.userInfo.phone || '未提供';
      requestData.pickupTime = new Date().toISOString();
    }
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: requestData,
      success: (res) => {
        if (res.result && res.result.success) {
          wx.showToast({ title: '操作成功', icon: 'success' });
          // 刷新当前标签页的订单列表
          this.setData({ 
            orderList: [], 
            classifiedOrders: {}, 
            currentPage: 1, 
            hasMore: true 
          }, () => {
            this.getOrderList();
          });
        } else {
          wx.showToast({ title: '操作失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('更新订单状态失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },

  // 查看订单详情
  viewOrderDetail(e) {
    const { orderId } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/order-detail/order-detail?orderId=${orderId}`
    });
  },

  // 上拉加载更多
  onReachBottom() {
    this.getOrderList();
  },

  // 返回上一页
  onBackTap() {
    wx.navigateBack();
  }
});