Page({
  data: {
    modules: [
      {
        id: 'orderManagement',
        name: '接单模块',
        icon: '/images/order-manage.png',
        description: '管理用户提交的代取订单'
      },
      {
        id: 'courierManagement',
        name: '代取手管理',
        icon: '/images/courier-manage.png',
        description: '管理代取人员信息和权限'
      },
      {
        id: 'courseManagement',
        name: '刷课管理',
        icon: '/images/course-manage.png',
        description: '管理代刷课程相关业务'
      },
      {
        id: 'errandManagement',
        name: '跑腿接单',
        icon: '/images/errand-manage.png',
        description: '处理各类跑腿任务'
      },
      {
        id: 'publishManagement',
        name: '发布管理',
        icon: '/images/publish-manage.png',
        description: '管理公告和通知发布'
      }
    ],
    isAdmin: false,
    loading: true
  },

  onLoad() {
    // 检查管理员权限
    this.checkAdminPermission();
  },

  // 检查是否为管理员
  checkAdminPermission() {
    console.log('开始检查管理员权限');
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkAdmin'
      },
      success: (res) => {
        console.log('管理员权限检查结果:', JSON.stringify(res.result));
        const isAdmin = res.result && res.result.success && res.result.isAdmin;
        
        if (!isAdmin) {
          wx.showToast({ title: '您不是管理员，无法访问管理端', icon: 'none' });
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        }
        
        this.setData({
          isAdmin,
          loading: false
        });
      },
      fail: (err) => {
        console.error('检查管理员权限失败:', err);
        wx.showToast({ title: '权限验证失败', icon: 'none' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
        this.setData({ loading: false });
      }
    });
  },

  // 点击模块进入相应管理页面
  onModuleTap(e) {
    const { moduleId } = e.currentTarget.dataset;
    
    switch(moduleId) {
      case 'orderManagement':
        wx.navigateTo({ url: '/pages/admin/admin' });
        break;
      case 'courierManagement':
        wx.navigateTo({ url: '/pages/courier-management/courier-management' });
        break;
      case 'courseManagement':
        wx.navigateTo({ url: '/pages/course-management/course-management' });
        break;
      case 'errandManagement':
        wx.navigateTo({ url: '/pages/errand-management/errand-management' });
        break;
      case 'publishManagement':
        wx.navigateTo({ url: '/pages/publish-management/publish-management' });
        break;
      default:
        wx.showToast({ title: '功能开发中', icon: 'none' });
    }
  },

  // 返回上一页
  onBackTap() {
    wx.navigateBack();
  }
});