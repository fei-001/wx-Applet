// 代取手接取订单页面
Page({
  data: {
    tabs: [
      { id: 'pending', name: '待处理' },
      { id: 'processing', name: '处理中' },
      { id: 'completed', name: '已完成' }
    ],
    activeTab: 'pending',
    orderList: [],
    classifiedOrders: [],
    isLoading: false,
    userInfo: null,
    isCourier: false
  },

  onLoad() {
    // 从本地存储获取用户信息
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({ userInfo });
      // 检查是否为代取手
      this.checkCourierPermission();
    } else {
      wx.showToast({ title: '请先登录', icon: 'none' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  onShow() {
    // 页面显示时重新获取订单列表
    if (this.data.isCourier) {
      this.getOrderList();
    }
  },

  // 检查是否为代取手
  checkCourierPermission() {
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkCourierStatus'
      },
      success: (res) => {
        const isCourier = res.result && res.result.success && res.result.isCourier;
        if (!isCourier) {
          wx.showToast({ title: '您不是代取手，无法访问', icon: 'none' });
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        } else {
          this.setData({ isCourier: true });
          this.getOrderList();
        }
      },
      fail: (err) => {
        console.error('检查代取手权限失败:', err);
        wx.showToast({ title: '权限验证失败', icon: 'none' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      }
    });
  },

  // 切换标签页
  onTabChange(e) {
    const { tabId } = e.currentTarget.dataset;
    this.setData({
      activeTab: tabId
    });
    this.getOrderList();
  },

  // 获取订单列表
  getOrderList() {
    this.setData({ isLoading: true });

    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getCourierOrders',
        status: this.data.activeTab,
        courierId: this.data.userInfo._id
      },
      success: (res) => {
        if (res.result && res.result.success) {
          // 预处理订单数据，计算快递总数量
          const processedOrders = (res.result.data || []).map(order => {
            // 计算快递总数量
            let totalExpressCount = 0;
            if (order.sizes && Array.isArray(order.sizes)) {
              totalExpressCount = order.sizes.reduce((sum, size) => sum + (size.count || 0), 0);
            }
            
            // 处理createTime，确保时间格式正确
            let formattedTime = '暂无时间数据';
            
            if (order.createTime) {
              let date;
              if (typeof order.createTime === 'object' && order.createTime._seconds) {
                date = new Date(order.createTime._seconds * 1000);
              } else if (typeof order.createTime === 'string') {
                date = new Date(order.createTime);
              } else if (typeof order.createTime === 'number') {
                date = new Date(order.createTime);
              }
              
              // 验证日期是否有效
              if (date && !isNaN(date.getTime())) {
                const year = date.getFullYear();
                const month = (date.getMonth() + 1).toString().padStart(2, '0');
                const day = date.getDate().toString().padStart(2, '0');
                const hours = date.getHours().toString().padStart(2, '0');
                const minutes = date.getMinutes().toString().padStart(2, '0');
                formattedTime = `${year}-${month}-${day} ${hours}:${minutes}`;
              }
            }
            
            return {
              ...order,
              totalExpressCount,
              expressType: order.expressType || '其他',
              status: order.status || 'pending',
              formattedTime: formattedTime
            };
          });
          
          // 按快递类型分类
          const classifiedOrders = this.classifyOrdersByExpressType(processedOrders);
          
          this.setData({
            orderList: processedOrders,
            classifiedOrders: classifiedOrders
          });
          // 更新标签页计数
          this.updateTabCounts(processedOrders);
        } else {
          wx.showToast({ title: '获取订单失败', icon: 'none' });
          this.setData({
            orderList: [],
            classifiedOrders: []
          });
        }
      },
      fail: (err) => {
        console.error('获取订单列表失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
        this.setData({
          orderList: [],
          classifiedOrders: []
        });
      },
      complete: () => {
        this.setData({ isLoading: false });
      }
    });
  },

  // 按快递类型分类订单
  classifyOrdersByExpressType(orders) {
    const classified = {};
    
    // 将订单按快递类型分组
    orders.forEach(order => {
      const expressType = order.expressType;
      if (!classified[expressType]) {
        classified[expressType] = [];
      }
      classified[expressType].push(order);
    });
    
    // 将分类后的订单转换为数组格式，方便wxml渲染
    const result = [];
    Object.keys(classified).forEach(type => {
      result.push({
        type: type,
        orders: classified[type]
      });
    });
    
    // 按订单数量降序排列分类
    return result.sort((a, b) => b.orders.length - a.orders.length);
  },

  // 更新标签页计数
  updateTabCounts(allOrders) {
    const tabs = [...this.data.tabs];
    tabs.forEach(tab => {
      tab.count = allOrders.filter(order => order.status === tab.id).length;
    });
    this.setData({ tabs });
  },

  // 接取订单
  acceptOrder(e) {
    const { orderId } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '确认接取',
      content: '确定要接取此订单吗？',
      success: (res) => {
        if (res.confirm) {
          this.updateOrderStatus(orderId, 'processing');
        }
      }
    });
  },

  // 完成订单
  completeOrder(e) {
    const { orderId } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '确认完成',
      content: '确定此订单已完成吗？',
      success: (res) => {
        if (res.confirm) {
          this.updateOrderStatus(orderId, 'completed');
        }
      }
    });
  },

  // 更新订单状态
  updateOrderStatus(orderId, status) {
    wx.showLoading({ title: '处理中...' });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'updateOrderStatus',
        orderId: orderId,
        status: status,
        courierId: this.data.userInfo._id
      },
      success: (res) => {
        if (res.result && res.result.success) {
          wx.showToast({ title: '操作成功', icon: 'success' });
          
          // 如果是接取订单操作(status为'processing')，则跳转到订单管理页面
          if (status === 'processing') {
            setTimeout(() => {
              wx.navigateTo({
                url: '/pages/order-management/order-management'
              });
            }, 1500);
          } else {
            // 其他状态更新则刷新订单列表
            this.getOrderList();
          }
        } else {
          wx.showToast({ title: '操作失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('更新订单状态失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },

  // 查看订单详情
  viewOrderDetail(e) {
    const { orderId } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/order/order?orderId=${orderId}&isCourier=true`
    });
  },
  
  // 返回上一页
  navigateBack() {
    wx.navigateBack();
  }
});