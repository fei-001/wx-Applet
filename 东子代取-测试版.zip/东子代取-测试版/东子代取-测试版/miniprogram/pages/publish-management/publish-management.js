Page({
  data: {
    publishList: [],
    isLoading: false,
    searchKey: '',
    filterType: 'all', // all, express, errand, course
    currentPage: 1,
    pageSize: 20,
    hasMore: true
  },

  onLoad() {
    this.checkAdminPermission();
    this.getPublishList();
  },

  // 检查管理员权限
  checkAdminPermission() {
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkAdmin'
      },
      success: (res) => {
        const isAdmin = res.result && res.result.success && res.result.isAdmin;
        if (!isAdmin) {
          wx.showToast({ title: '您不是管理员，无法访问', icon: 'none' });
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        }
      },
      fail: (err) => {
        console.error('检查管理员权限失败:', err);
        wx.showToast({ title: '权限验证失败', icon: 'none' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      }
    });
  },

  // 获取发布任务列表
  getPublishList() {
    if (this.data.isLoading || !this.data.hasMore) return;
    
    this.setData({ isLoading: true });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getAllTasks',
        searchKey: this.data.searchKey,
        taskType: this.data.filterType,
        page: this.data.currentPage,
        pageSize: this.data.pageSize
      },
      success: (res) => {
        if (res.result && res.result.success) {
          const newPublishes = res.result.data || [];
          const updatedList = this.data.currentPage === 1 ? newPublishes : [...this.data.publishList, ...newPublishes];
          
          this.setData({
            publishList: updatedList,
            hasMore: newPublishes.length === this.data.pageSize,
            currentPage: this.data.currentPage + 1
          });
        } else {
          wx.showToast({ title: '获取发布任务失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('获取发布任务失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        this.setData({ isLoading: false });
      }
    });
  },

  // 搜索发布任务
  onSearch(e) {
    const { value } = e.detail;
    this.setData({
      searchKey: value,
      currentPage: 1,
      hasMore: true
    }, () => {
      this.getPublishList();
    });
  },

  // 切换筛选类型
  onFilterTypeChange(e) {
    const { type } = e.currentTarget.dataset;
    this.setData({
      filterType: type,
      currentPage: 1,
      hasMore: true
    }, () => {
      this.getPublishList();
    });
  },

  // 删除发布任务
  deletePublish(e) {
    const { taskId, taskType } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除此发布任务吗？此操作不可撤销。',
      success: (res) => {
        if (res.confirm) {
          this.submitDeletePublish(taskId, taskType);
        }
      }
    });
  },

  // 提交删除操作
  submitDeletePublish(taskId, taskType) {
    wx.showLoading({ title: '处理中...' });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'deleteTask',
        taskId: taskId,
        taskType: taskType
      },
      success: (res) => {
        if (res.result && res.result.success) {
          wx.showToast({ title: '删除成功', icon: 'success' });
          // 刷新列表
          this.setData({ currentPage: 1, hasMore: true }, () => {
            this.getPublishList();
          });
        } else {
          wx.showToast({ title: '删除失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('删除任务失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },

  // 查看任务详情
  onPublishDetail(e) {
    const { task } = e.currentTarget.dataset;
    const taskType = task.taskType || 'express'; // 默认快递类型
    
    if (taskType === 'express') {
      wx.navigateTo({
        url: `/pages/order-detail/order-detail?orderId=${task._id}`
      });
    } else if (taskType === 'errand') {
      wx.navigateTo({
        url: `/pages/errand-detail/errand-detail?taskId=${task._id}`
      });
    } else if (taskType === 'course') {
      wx.navigateTo({
        url: `/pages/course-detail/course-detail?taskId=${task._id}`
      });
    }
  },

  // 添加新发布任务
  onAddPublish() {
    wx.showActionSheet({
      itemList: ['快递代取', '跑腿服务', '刷课服务'],
      success: (res) => {
        if (!res.cancel) {
          switch(res.tapIndex) {
            case 0:
              wx.navigateTo({ url: '/pages/express-publish/express-publish' });
              break;
            case 1:
              wx.navigateTo({ url: '/pages/errand-publish/errand-publish' });
              break;
            case 2:
              wx.navigateTo({ url: '/pages/course-publish/course-publish' });
              break;
          }
        }
      }
    });
  },

  // 上拉加载更多
  onReachBottom() {
    this.getPublishList();
  },

  // 返回上一页
  onBackTap() {
    wx.navigateBack();
  }
});