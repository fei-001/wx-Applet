Page({
  data: {
    tabs: [
      { id: 'pending', name: '待处理' },
      { id: 'processing', name: '处理中' },
      { id: 'completed', name: '已完成' },
      { id: 'rejected', name: '已拒绝' }
    ],
    activeTab: 'pending',
    orderList: [],
    classifiedOrders: [],
    isLoading: false,
    isAdmin: false,
    isCourier: false,
    userInfo: null
  },

  onLoad() {
    // 检查用户权限
    this.checkUserPermission();
  },

  onShow() {
    // 只有在权限验证成功后才重新获取订单列表
    if ((this.data.isAdmin || this.data.isCourier) && this.data.userInfo) {
      this.getOrderList();
    }
  },

  // 检查用户权限（管理员或代取手）
  checkUserPermission() {
    // 保存用户信息到全局数据
    const userInfo = wx.getStorageSync('userInfo');
    
    // 如果没有用户信息，直接拒绝访问
    if (!userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
      return;
    }
    
    this.setData({ userInfo });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkUserPermissions'
      },
      success: (res) => {
        console.log('用户权限检查结果:', res.result);
        const isAdmin = res.result && res.result.isAdmin;
        const isCourier = res.result && res.result.isCourier;
        
        if (!isAdmin && !isCourier) {
          wx.showToast({ title: '您无权访问此页面，只有代取手和管理员可浏览', icon: 'none' });
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        } else {
          // 保存用户权限状态
          this.setData({
            isAdmin: isAdmin || false,
            isCourier: isCourier || false
          });
          // 权限验证成功后获取订单列表
          this.getOrderList();
        }
      },
      fail: (err) => {
        console.error('检查用户权限失败:', err);
        wx.showToast({ title: '权限验证失败', icon: 'none' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      }
    });
  },

  // 切换标签页
  onTabChange(e) {
    const { tabId } = e.currentTarget.dataset;
    console.log(`切换到标签页: ${tabId}`);
    this.setData({
      activeTab: tabId
    });
    this.getOrderList();
  },

  // 获取订单列表
  getOrderList() {
    // 双重检查权限
    if (!this.data.isAdmin && !this.data.isCourier) {
      console.warn('无权限获取订单列表');
      wx.showToast({ title: '您无权访问此页面', icon: 'none' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
      return;
    }
    
    console.log(`开始获取订单列表，当前标签: ${this.data.activeTab}`);
    this.setData({ isLoading: true });

    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getAllOrders' // 不传递status参数，获取所有订单后在前端过滤
      },
      success: (res) => {
        console.log('获取订单列表结果:', JSON.stringify(res));
        if (res.result && res.result.success) {
          console.log(`获取到的订单数量: ${res.result.data ? res.result.data.length : 0}`);
          
          // 预处理订单数据，计算快递总数量
            let processedOrders = (res.result.data || []).map((order, index) => {
            // 打印第一个订单的详细信息用于调试
            if (index === 0) {
              console.log('第一个订单的详细信息:', JSON.stringify(order));
            }
            
            // 计算快递总数量
            let totalExpressCount = 0;
            if (order.sizes && Array.isArray(order.sizes)) {
              totalExpressCount = order.sizes.reduce((sum, size) => sum + (size.count || 0), 0);
            }
            
            // 处理createTime，确保时间格式正确
            let formattedTime = '暂无时间数据';
            
            if (order.createTime) {
              let date;
              if (typeof order.createTime === 'object' && order.createTime._seconds) {
                date = new Date(order.createTime._seconds * 1000);
              } else if (typeof order.createTime === 'string') {
                date = new Date(order.createTime);
              } else if (typeof order.createTime === 'number') {
                date = new Date(order.createTime);
              } else if (order.createTime instanceof Date) {
                date = order.createTime;
              }
              
              // 验证日期是否有效
              if (date && !isNaN(date.getTime())) {
                // 直接在JS中格式化时间，避免模板中再调用formatTime
                const year = date.getFullYear();
                const month = (date.getMonth() + 1).toString().padStart(2, '0');
                const day = date.getDate().toString().padStart(2, '0');
                const hours = date.getHours().toString().padStart(2, '0');
                const minutes = date.getMinutes().toString().padStart(2, '0');
                formattedTime = `${year}-${month}-${day} ${hours}:${minutes}`;
              }
            }
            
            // 格式化接单时间
            let formattedPickupTime = '未提供';
            if (order.pickupTime) {
              let date;
              if (typeof order.pickupTime === 'object' && order.pickupTime._seconds) {
                date = new Date(order.pickupTime._seconds * 1000);
              } else if (typeof order.pickupTime === 'string') {
                date = new Date(order.pickupTime);
              } else if (typeof order.pickupTime === 'number') {
                date = new Date(order.pickupTime);
              } else if (order.pickupTime instanceof Date) {
                date = order.pickupTime;
              }
              
              // 验证日期是否有效
              if (date && !isNaN(date.getTime())) {
                const year = date.getFullYear();
                const month = (date.getMonth() + 1).toString().padStart(2, '0');
                const day = date.getDate().toString().padStart(2, '0');
                const hours = date.getHours().toString().padStart(2, '0');
                const minutes = date.getMinutes().toString().padStart(2, '0');
                formattedPickupTime = `${year}-${month}-${day} ${hours}:${minutes}`;
              }
            }
            
            // 格式化完成时间
            let formattedCompleteTime = '未提供';
            if (order.completeTime) {
              let date;
              if (typeof order.completeTime === 'object' && order.completeTime._seconds) {
                date = new Date(order.completeTime._seconds * 1000);
              } else if (typeof order.completeTime === 'string') {
                date = new Date(order.completeTime);
              } else if (typeof order.completeTime === 'number') {
                date = new Date(order.completeTime);
              } else if (order.completeTime instanceof Date) {
                date = order.completeTime;
              }
              
              // 验证日期是否有效
              if (date && !isNaN(date.getTime())) {
                const year = date.getFullYear();
                const month = (date.getMonth() + 1).toString().padStart(2, '0');
                const day = date.getDate().toString().padStart(2, '0');
                const hours = date.getHours().toString().padStart(2, '0');
                const minutes = date.getMinutes().toString().padStart(2, '0');
                formattedCompleteTime = `${year}-${month}-${day} ${hours}:${minutes}`;
              }
            }
            
            return {
              ...order,
              totalExpressCount,
              // 确保expressType有值
              expressType: order.expressType || '其他',
              // 确保status有值
              status: order.status || 'pending',
              // 添加预格式化的时间，方便模板直接使用
              formattedTime: formattedTime,
              // 添加格式化的接单时间
              pickupTime: formattedPickupTime,
              // 添加格式化的完成时间
              completeTime: formattedCompleteTime
            };
            });
          
          // 先根据activeTab过滤订单
          const activeTab = this.data.activeTab;
          let filteredOrdersByTab;
          
          // 管理员可以查看该标签下的所有订单，不受任何用户ID限制
            if (this.data.isAdmin) {
              filteredOrdersByTab = processedOrders.filter(order => order.status === activeTab);
              console.log('管理员查看该标签下的所有订单');
              console.log(`管理员在标签(${activeTab})下可见订单数量: ${filteredOrdersByTab.length}`);
              // 确保管理员订单不被任何额外条件过滤
              console.log('管理员角色，跳过任何基于用户ID的过滤');
            } else {
              // 非管理员用户按标签过滤订单
              filteredOrdersByTab = processedOrders.filter(order => order.status === activeTab);
              console.log(`根据标签(${activeTab})过滤后订单数量: ${filteredOrdersByTab.length}`);
              
              // 如果是代取手，只显示自己接取的订单，但待处理板块应显示所有订单
              if (this.data.isCourier && this.data.userInfo && 
                  (this.data.activeTab === 'processing' || this.data.activeTab === 'completed')) {
                  const currentUserId = this.data.userInfo._id;
                  filteredOrdersByTab = filteredOrdersByTab.filter(order => 
                    order.courierId === currentUserId
                  );
                console.log(`代取手过滤后订单数量: ${filteredOrdersByTab.length}, 当前用户ID: ${currentUserId}`);
              }
            }
            
            // 打印订单过滤前的数量和当前用户角色状态，用于调试
            console.log(`订单过滤后数量: ${filteredOrdersByTab.length}, 当前角色: isCourier=${this.data.isCourier}, isAdmin=${this.data.isAdmin}, 当前标签: ${this.data.activeTab}`);
          
          // 打印订单过滤后的数量
            console.log(`订单过滤后数量: ${filteredOrdersByTab.length}`);
            
            // 对处理中和已完成状态的订单按下单时间降序排序
            if (this.data.activeTab === 'processing' || this.data.activeTab === 'completed') {
              filteredOrdersByTab.sort((a, b) => {
              // 获取两个订单的时间戳
              const getTimeStamp = (order) => {
                if (order.createTime) {
                  if (typeof order.createTime === 'object' && order.createTime._seconds) {
                    return order.createTime._seconds;
                  } else if (typeof order.createTime === 'string') {
                    return new Date(order.createTime).getTime() / 1000;
                  } else if (typeof order.createTime === 'number') {
                    return order.createTime;
                  } else if (order.createTime instanceof Date) {
                    return order.createTime.getTime() / 1000;
                  }
                }
                return 0;
              };
              
              const timeA = getTimeStamp(a);
              const timeB = getTimeStamp(b);
              
              // 降序排序（最新的订单在前）
              return timeB - timeA;
            });
          }
          
          // 按快递类型分类
          const classifiedOrders = this.classifyOrdersByExpressType(filteredOrdersByTab);
          console.log(`分类后的订单: ${JSON.stringify(classifiedOrders)}`);
          
          this.setData({
            orderList: filteredOrdersByTab,
            classifiedOrders: classifiedOrders
          });
          // 更新标签页计数
          this.updateTabCounts(processedOrders);
        } else {
          console.error('获取订单失败，结果:', res.result);
          wx.showToast({ title: '获取订单失败: ' + (res.result?.errMsg || '未知错误'), icon: 'none' });
          // 即使获取失败，也设置空数组避免页面显示异常
          this.setData({
            orderList: [],
            classifiedOrders: []
          });
        }
      },
      fail: (err) => {
        console.error('获取订单列表失败:', err);
        wx.showToast({ title: '网络错误: ' + (err.errMsg || '未知错误'), icon: 'none' });
        // 即使网络错误，也设置空数组避免页面显示异常
        this.setData({
          orderList: [],
          classifiedOrders: []
        });
      },
      complete: () => {
        this.setData({ isLoading: false });
        console.log('订单获取完成，当前订单列表状态:', {
          orderListLength: this.data.orderList.length,
          classifiedOrdersLength: this.data.classifiedOrders.length
        });
      }
    });
  },

  // 按快递类型分类订单
  classifyOrdersByExpressType(orders) {
    const classified = {};
    
    // 将订单按快递类型分组
    orders.forEach(order => {
      const expressType = order.expressType;
      if (!classified[expressType]) {
        classified[expressType] = [];
      }
      classified[expressType].push(order);
    });
    
    // 将分类后的订单转换为数组格式，方便wxml渲染
    const result = [];
    Object.keys(classified).forEach(type => {
      result.push({
        type: type,
        orders: classified[type]
      });
    });
    
    // 按订单数量降序排列分类
    return result.sort((a, b) => b.orders.length - a.orders.length);
  },

  // 更新标签页计数
  updateTabCounts(allOrders) {
    const tabs = [...this.data.tabs];
    const { isAdmin, isCourier, userInfo } = this.data;
    const currentUserId = userInfo ? userInfo._id : '';
    
    tabs.forEach(tab => {
      // 过滤当前标签页的所有订单
      const tabOrders = allOrders.filter(order => order.status === tab.id);
      let count = 0;
      
      // 管理员可以查看所有订单数量
      if (isAdmin) {
        count = tabOrders.length;
        console.log(`管理员标签计数 - ${tab.name}: ${count} 个订单`);
      } else {
        // 非管理员用户按标签和状态过滤订单
        count = tabOrders.length;
        
        // 如果是代取手，且在处理中和已完成标签，只显示自己的订单数量
        if (isCourier && currentUserId && 
            (tab.id === 'processing' || tab.id === 'completed')) {
          count = tabOrders.filter(order => order.courierId === currentUserId).length;
          console.log(`代取手标签计数 - ${tab.name}: ${count} 个订单, 用户ID: ${currentUserId}`);
        }
      }
      
      tab.count = count;
    });
    
    this.setData({ tabs });
    console.log('更新标签页计数后:', this.data.tabs);
  },

  // 接单
  onAcceptOrder(e) {
    // 检查权限
    if (!this.data.isAdmin && !this.data.isCourier) {
      wx.showToast({ title: '您无权执行此操作', icon: 'none' });
      return;
    }
    
    const { orderId } = e.currentTarget.dataset;
    // 获取当前登录用户信息，提取代取手ID
    const userInfo = wx.getStorageSync('userInfo');
    const courierId = userInfo ? userInfo._id : '';
    
    if (!courierId) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    
    this.updateOrderStatus(orderId, 'processing', '', courierId);
  },

  // 拒绝订单
  onRejectOrder(e) {
    // 检查权限
    if (!this.data.isAdmin && !this.data.isCourier) {
      wx.showToast({ title: '您无权执行此操作', icon: 'none' });
      return;
    }
    
    const { orderId } = e.currentTarget.dataset;
    wx.showModal({
      title: '拒绝订单',
      content: '请输入拒绝原因',
      editable: true,
      placeholderText: '请输入拒绝该订单的原因',
      success: (res) => {
        if (res.confirm) {
          // 确保拒绝原因不为空
          const rejectReason = res.content.trim() || '订单已被拒绝';
          this.updateOrderStatus(orderId, 'rejected', rejectReason);
        }
      }
    });
  },

  // 完成订单
  onCompleteOrder(e) {
    // 检查权限
    if (!this.data.isAdmin && !this.data.isCourier) {
      wx.showToast({ title: '您无权执行此操作', icon: 'none' });
      return;
    }
    
    const { orderId } = e.currentTarget.dataset;
    wx.showModal({
      title: '完成订单',
      content: '请输入备注信息（可选）',
      editable: true,
      placeholderText: '输入备注信息',
      success: (res) => {
        if (res.confirm) {
          this.updateOrderStatus(orderId, 'completed', res.content || '');
        }
      }
    });
  },

  // 更新订单状态
  updateOrderStatus(orderId, status, remark, courierId) {
    // 检查权限
    if (!this.data.isAdmin && !this.data.isCourier) {
      wx.showToast({ title: '您无权执行此操作', icon: 'none' });
      return;
    }
    
    wx.showLoading({ title: '处理中...' });

    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'updateOrderStatus',
        orderId: orderId,
        status: status,
        remark: remark,
        courierId: courierId // 传递代取手ID
      },
      success: (res) => {
        console.log('更新订单状态结果:', res.result);
        if (res.result && res.result.success) {
          wx.showToast({ title: '操作成功', icon: 'success' });
          // 重新获取订单列表
          this.getOrderList();
        } else {
          wx.showToast({ title: res.result?.errMsg || '操作失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('更新订单状态失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },

  // 查看订单详情
  onOrderDetail(e) {
    const { order } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/order/order?orderId=${order._id}&viewMode=admin`
    });
  }
});