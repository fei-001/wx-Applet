// login.js
Page({
  data: {
    errorMsg: '',
    showPlugin: false,
    modal: {
      title: '用户登录',
      content: '授权登录后，开始使用完整功能',
      confirmText: '登录',
      cancelText: '暂不'
    }
  },

  onLoad() {
    // 页面加载时检查是否已登录
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      wx.showToast({ title: '您已登录，无需重复登录', icon: 'none' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  // 返回按钮点击事件
  onBackTap() {
    wx.navigateBack();
  },

  // 微信一键登录按钮点击事件
  onWechatLogin() {
    this.setData({ showPlugin: true });
  },

  // 安全注册插件成功回调
  onRegisterSuccess(e) {
    console.log('安全注册插件登录成功回调:', e);
    console.log('回调详情:', JSON.stringify(e));
    this.setData({ showPlugin: false });
    
    try {
      // 获取用户信息
      const userInfo = e.detail?.userInfo || e.detail?.res; // 同时支持不同格式的返回数据
      const encryptedData = e.detail?.encryptedData;
      const iv = e.detail?.iv;
      const code = e.detail?.code;
      
      console.log('从插件获取的参数:', { hasUserInfo: !!userInfo, hasEncryptedData: !!encryptedData, hasIv: !!iv, hasCode: !!code });
      console.log('插件返回的真实用户信息:', JSON.stringify(userInfo || {}));
      
      // 保存登录所需的参数到页面数据
      this.setData({
        pendingLoginData: {
          code,
          encryptedData,
          iv,
          userInfo: userInfo || null
        }
      });
      
      // 直接使用插件返回的真实用户信息调用云函数登录
      // 不需要额外调用wx.getUserProfile，因为插件已提供真实信息
      console.log('直接使用插件返回的真实用户信息进行登录');
      this.callCloudFunctionForLogin(code, encryptedData, iv, userInfo);
    } catch (error) {
      console.error('处理登录结果失败:', error);
      this.handleLoginError('登录失败，请稍后重试');
    }
  },
  
  // 调用云函数进行登录验证的封装函数
  callCloudFunctionForLogin(code, encryptedData, iv, userInfo) {
    wx.showLoading({ title: '登录中...' });
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'login',
        code: code || 'fallback_code',
        encryptedData: encryptedData || '',
        iv: iv || '',
        userInfo: userInfo,
        isTest: false // 这不是测试模式
      },
      success: res => {
        wx.hideLoading();
        console.log('云函数登录成功:', res.result);
        
        if (res.result.success) {
          // 登录成功，保存用户信息到本地存储
          const userInfoData = res.result.userInfo;
          wx.setStorageSync('userInfo', userInfoData);
          
          // 显示成功提示并返回上一页
          wx.showToast({
            title: '登录成功',
            icon: 'success',
            duration: 1500,
            success: () => {
              setTimeout(() => {
                wx.navigateBack();
              }, 1500);
            }
          });
        } else {
          this.handleLoginError(res.result.errMsg || '登录失败');
        }
      },
      fail: err => {
        wx.hideLoading();
        console.error('云函数调用失败:', err);
        this.handleLoginError('网络异常，请稍后重试');
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },

  // 安全注册插件失败回调
  onRegisterFail(e) {
    console.log('安全注册插件登录失败回调:', e);
    console.log('失败回调详情:', JSON.stringify(e));
    this.setData({ showPlugin: false });
    
    // 某些手机端会出现登录失败情况，按照用户要求，这里按照登录成功处理
    wx.showLoading({ title: '登录中...' });
    
    // 调用云函数进行登录验证（使用测试模式）
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'login',
        code: 'test_code',
        encryptedData: 'test_encrypted_data',
        iv: 'test_iv',
        isTest: true
      },
      success: res => {
        wx.hideLoading();
        console.log('测试登录成功:', res.result);
        
        if (res.result.success) {
          // 保存用户信息到本地存储
          const userInfoData = res.result.userInfo;
          wx.setStorageSync('userInfo', userInfoData);
          
          // 显示成功提示并返回上一页
          wx.showToast({
            title: '登录成功',
            icon: 'success',
            duration: 1500,
            success: () => {
              setTimeout(() => {
                wx.navigateBack();
              }, 1500);
            }
          });
        } else {
          this.handleLoginError('登录失败，请稍后重试');
        }
      },
      fail: err => {
        wx.hideLoading();
        console.error('云函数调用失败:', err);
        this.handleLoginError('网络异常，请稍后重试');
      }
    });
  },

  // 安全注册插件取消回调
  onRegisterCancel(e) {
    console.log('用户取消登录:', e);
    this.setData({ showPlugin: false });
  },



  // 处理登录错误
  handleLoginError(errMsg) {
    this.setData({ errorMsg: errMsg });
    // 3秒后清除错误提示
    setTimeout(() => {
      this.setData({ errorMsg: '' });
    }, 3000);
  },

  // 检查网络状态
  checkNetwork() {
    return new Promise((resolve, reject) => {
      wx.getNetworkType({
        success: res => {
          const networkType = res.networkType;
          if (networkType === 'none') {
            reject(new Error('当前无网络连接'));
          } else {
            resolve(networkType);
          }
        },
        fail: err => {
          reject(err);
        }
      });
    });
  }
});