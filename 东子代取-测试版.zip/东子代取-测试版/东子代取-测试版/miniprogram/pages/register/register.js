Page({
  data: {
    studentId: '',
    phone: '',
    password: '',
    errorMsg: ''
  },

  onBackTap() {
    wx.navigateBack();
  },

  onStudentIdInput(e) {
    this.setData({ studentId: e.detail.value });
  },

  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
  },

  onPasswordInput(e) {
    this.setData({ password: e.detail.value });
  },

  async onRegisterSubmit() {
    const { studentId, phone, password } = this.data;
    if (!studentId || !phone || !password) {
      this.setData({ errorMsg: '请填写所有字段' });
      return;
    }
    try {
      const res = await wx.cloud.callFunction({
        name: 'quickstartFunctions',
        data: { type: 'register', username: studentId, phone, password }
      });
      if (res.result.success) {
        wx.showToast({ title: '注册成功', icon: 'success' });
        wx.navigateBack();
      } else {
        this.setData({ errorMsg: res.result.errMsg || '注册失败，请重试' });
      }
    } catch (err) {
      this.setData({ errorMsg: '注册失败，请重试' });
    }
  }
});