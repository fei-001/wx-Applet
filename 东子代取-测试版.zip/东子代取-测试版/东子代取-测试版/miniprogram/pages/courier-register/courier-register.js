// 代取手注册页面
Page({
  data: {
    formData: {
      name: '',
      dormitory: '',
      phone: '',
      wechat: '',
      college: '',
      grade: '',
      className: '',
      avatarUrl: ''
    },
    errors: {},
    isSubmitting: false,
    userInfo: null
  },

  onLoad() {
    // 检查用户是否已登录
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
      return;
    }
    this.setData({ userInfo });
  },

  // 表单输入处理
  onInput(e) {
    const { field } = e.currentTarget.dataset;
    const { value } = e.detail;
    
    // 更新表单数据
    const formData = this.data.formData;
    formData[field] = value;
    this.setData({ formData });
    
    // 清除对应的错误提示
    if (this.data.errors[field]) {
      const errors = this.data.errors;
      delete errors[field];
      this.setData({ errors });
    }
  },

  // 选择头像
  onChooseAvatar() {
    const that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        const tempFilePath = res.tempFilePaths[0];
        that.uploadAvatar(tempFilePath);
      },
      fail(err) {
        console.error('选择头像失败:', err);
        wx.showToast({ title: '选择头像失败', icon: 'none' });
      }
    });
  },

  // 上传头像到云存储
  uploadAvatar(tempFilePath) {
    wx.showLoading({ title: '上传头像中...' });
    
    const cloudPath = `courier-avatars/${Date.now()}-${Math.floor(Math.random() * 1000)}.${tempFilePath.match(/\.[^.]+?$/)[0]}`;
    
    wx.cloud.uploadFile({
      cloudPath: cloudPath,
      filePath: tempFilePath,
      success: res => {
        // 获取上传后的文件ID
        const fileID = res.fileID;
        console.log('头像上传成功，fileID:', fileID);
        
        // 更新表单中的头像URL
        const formData = this.data.formData;
        formData.avatarUrl = fileID;
        this.setData({ formData });
        
        wx.hideLoading();
        wx.showToast({ title: '头像上传成功', icon: 'success' });
      },
      fail: err => {
        console.error('头像上传失败:', err);
        wx.hideLoading();
        wx.showToast({ title: '头像上传失败，请重试', icon: 'none' });
      }
    });
  },

  // 表单验证
  validateForm() {
    const { formData } = this.data;
    const errors = {};
    
    // 验证姓名
    if (!formData.name.trim()) {
      errors.name = '请输入姓名';
    }
    
    // 验证宿舍号
    if (!formData.dormitory.trim()) {
      errors.dormitory = '请输入宿舍号';
    }
    
    // 验证手机号
    if (!formData.phone.trim()) {
      errors.phone = '请输入手机号';
    } else if (!/^1[3-9]\d{9}$/.test(formData.phone)) {
      errors.phone = '请输入正确的11位手机号';
    }
    
    // 验证微信号
    if (!formData.wechat.trim()) {
      errors.wechat = '请输入微信号';
    }
    
    // 验证学院
    if (!formData.college.trim()) {
      errors.college = '请输入学院';
    }
    
    // 验证年级
    if (!formData.grade.trim()) {
      errors.grade = '请输入年级';
    }
    
    // 验证班级
    if (!formData.className.trim()) {
      errors.className = '请输入班级';
    }
    
    // 验证头像
    if (!formData.avatarUrl) {
      errors.avatarUrl = '请上传头像';
    }
    
    this.setData({ errors });
    return Object.keys(errors).length === 0;
  },

  // 提交表单
  onSubmit() {
    // 验证表单
    if (!this.validateForm()) {
      return;
    }
    
    // 检查是否正在提交
    if (this.data.isSubmitting) {
      return;
    }
    
    this.setData({ isSubmitting: true });
    wx.showLoading({ title: '提交中...' });
    
    // 构造提交数据
    const submitData = {
      ...this.data.formData,
      userId: this.data.userInfo._id,
      createTime: Date.now(),
      status: 'pending', // 待审核状态
      orderCount: 0
    };
    
    // 调用云函数提交数据
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'registerCourier',
        courierData: submitData
      },
      success: res => {
        console.log('代取手注册结果:', res);
        if (res.result && res.result.success) {
          wx.hideLoading();
          wx.showToast({
            title: '注册成功，请等待审核',
            icon: 'success',
            duration: 2000,
            success: () => {
              setTimeout(() => {
                // 清空表单数据
                this.setData({
                  formData: {
                    name: '',
                    dormitory: '',
                    phone: '',
                    wechat: '',
                    college: '',
                    grade: '',
                    className: '',
                    avatarUrl: ''
                  }
                });
                // 返回首页
                wx.navigateTo({
                  url: '/pages/index/index'
                });
              }, 2000);
            }
          });
        } else {
          wx.hideLoading();
          wx.showToast({ 
            title: res.result ? res.result.message : '注册失败，请重试', 
            icon: 'none' 
          });
          this.setData({ isSubmitting: false });
        }
      },
      fail: err => {
        console.error('代取手注册失败:', err);
        wx.hideLoading();
        wx.showToast({ title: '网络错误，请重试', icon: 'none' });
        this.setData({ isSubmitting: false });
      }
    });
  },

  // 返回上一页
  onBackTap() {
    wx.navigateBack();
  }
});