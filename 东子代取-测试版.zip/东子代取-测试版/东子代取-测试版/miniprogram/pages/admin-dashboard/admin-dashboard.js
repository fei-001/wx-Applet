// 管理首页 - 管理员功能入口
Page({
  data: {
    modules: [
      {
        id: 'orderManagement',
        name: '接取订单',
        icon: '/images/box-icon.png',
        description: '管理和处理所有订单',
        url: '/pages/admin/admin'
      },
      {
        id: 'courierManagement',
        name: '代取手管理',
        icon: '/images/user-icon.png',
        description: '管理代取手信息',
        url: '/pages/courier-management/courier-management',
        disabled: false
      },
      {
        id: 'courseBrushManagement',
        name: '刷课管理',
        icon: '/images/book-icon.png',
        description: '课程代刷相关管理',
        url: '#',
        disabled: true
      },
      {
        id: 'errandManagement',
        name: '跑腿接单',
        icon: '/images/run-icon.png',
        description: '管理跑腿任务',
        url: '#',
        disabled: true
      },
      {
        id: 'publishManagement',
        name: '发布管理',
        icon: '/images/edit-icon.png',
        description: '管理发布内容',
        url: '#',
        disabled: true
      }
    ],
    isAdmin: false
  },

  onLoad() {
    // 检查是否为管理员
    this.checkAdminPermission();
  },

  // 检查是否为管理员
  checkAdminPermission() {
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkAdmin'
      },
      success: (res) => {
        const isAdmin = res.result && res.result.success && res.result.isAdmin;
        if (!isAdmin) {
          wx.showToast({ title: '您不是管理员，无法访问', icon: 'none' });
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        } else {
          this.setData({ isAdmin: true });
        }
      },
      fail: (err) => {
        console.error('检查管理员权限失败:', err);
        wx.showToast({ title: '权限验证失败', icon: 'none' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      }
    });
  },

  // 模块点击事件
  onModuleTap(e) {
    const { url, disabled } = e.currentTarget.dataset;
    if (disabled) {
      wx.showToast({ title: '功能暂未开发', icon: 'none' });
      return;
    }
    wx.navigateTo({ url });
  }
});