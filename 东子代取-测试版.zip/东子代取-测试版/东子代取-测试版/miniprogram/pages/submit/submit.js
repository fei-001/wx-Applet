Page({
  data: {
    codeError: '',
    infoError: '',
    countError: '', // 取件码与数量不匹配的错误提示
    expressCodes: [], // 存储多个取件码
    pickupInfoList: [
      { name: '', phone: '', address: '' },
      { name: '', phone: '', address: '' },
      { name: '', phone: '', address: '' }
    ],
    currentInfoIndex: 0,
    selectedInfoIndex: -1,
  selectedType: null,
    showPaymentModal: false,
    expressTypes: [
      { id: 'post', name: '菜鸟驿站', icon: '/images3/one.jpg' },
      { id: 'zhongtong', name: '申通', icon: '/images3/two.jpg' },
      { id: 'shunfeng', name: '顺丰', icon: '/images/five.jpg' },
      { id: 'yunda', name: '韵达', icon: '/images3/three.jpg' },
      { id: 'jitu', name: '妈妈驿站', icon: '/images/fore.jpg' }
    ],
    sizeTypes: [
      { id: 'large', name: '大件', price: 1.5, count: 0, error: '' },
      { id: 'medium', name: '中件', price: 1, count: 0, error: '' },
      { id: 'small', name: '小件', price: 0.5, count: 0, error: '' }
    ],
    feeDetails: [],
    totalFee: 0,
    isSubmitDisabled: true
  },

  onBackTap() {
    wx.navigateBack();
  },

  onLoad() {
    // 页面加载时，从本地存储读取取件信息
    this.loadPickupInfo();
    // 初始化添加一个取件码输入框
    this.setData({ expressCodes: [{ code: '', error: '' }] });
  },

  onShow() {
    // 页面显示时，再次读取数据，确保与最新状态同步
    this.loadPickupInfo();
  },

  // 从本地存储加载取件信息
  loadPickupInfo() {
    try {
      // 读取取件信息列表
      const savedInfoList = wx.getStorageSync('pickupInfoList');
      if (savedInfoList) {
        this.setData({
          pickupInfoList: JSON.parse(savedInfoList)
        });
      }

      // 读取默认信息索引
      const savedCurrentIndex = wx.getStorageSync('currentPickupInfoIndex');
      if (savedCurrentIndex !== '') {
        this.setData({
          currentInfoIndex: savedCurrentIndex,
          selectedInfoIndex: savedCurrentIndex // 默认选中当前设置的默认信息
        });
      }
    } catch (e) {
      console.error('读取取件信息失败:', e);
    }
  },

  // 选择取件信息
  onSelectInfo(e) {
    const { index } = e.currentTarget.dataset;
    this.setData({ 
      selectedInfoIndex: index,
      infoError: ''
    }, () => this.checkSubmitStatus());
  },

  // 添加取件码输入框
  onAddCode() {
    const expressCodes = this.data.expressCodes;
    expressCodes.push({ code: '', error: '' });
    
    // 当添加新的取件码时，自动增加小件数量
    const sizeTypes = this.data.sizeTypes.map(item => {
      if (item.id === 'small') {
        return { ...item, count: item.count + 1, error: '' };
      }
      return item;
    });
    
    this.setData({ expressCodes, sizeTypes }, () => {
      this.validateAllCodes();
      this.calculateFee();
      this.checkSubmitStatus();
    });
  },

  // 删除取件码输入框
  onRemoveCode(e) {
    const { index } = e.currentTarget.dataset;
    const expressCodes = this.data.expressCodes.filter((_, i) => i !== index);
    
    // 当删除取件码时，如果小件数量大于取件码数量，自动减少小件数量
    let sizeTypes = this.data.sizeTypes;
    const smallItem = sizeTypes.find(item => item.id === 'small');
    if (smallItem && smallItem.count > expressCodes.length) {
      sizeTypes = sizeTypes.map(item => {
        if (item.id === 'small') {
          return { ...item, count: expressCodes.length, error: '' };
        }
        return item;
      });
    }
    
    this.setData({ expressCodes, sizeTypes }, () => {
      this.validateAllCodes();
      this.calculateFee();
      this.checkSubmitStatus();
    });
  },

  // 单个取件码输入处理
  onCodeInput(e) {
    const { index } = e.currentTarget.dataset;
    const code = e.detail.value;
    
    // 更新对应的取件码
    const expressCodes = [...this.data.expressCodes];
    expressCodes[index] = {
      code,
      error: !code ? '取件码不能为空' : ''
    };
    
    this.setData({ expressCodes }, () => {
      this.validateAllCodes();
      this.checkSubmitStatus();
    });
  },

  // 验证所有取件码
  validateAllCodes() {
    const hasEmptyCode = this.data.expressCodes.some(item => !item.code);
    this.setData({
      codeError: hasEmptyCode ? '请填写所有取件码' : ''
    });
  },

  onTypeSelect(e) {
    const { id } = e.currentTarget.dataset;
    this.setData({ selectedType: id }, () => this.checkSubmitStatus());
  },

  onMinus(e) {
    const { id } = e.currentTarget.dataset;
    const sizeTypes = this.data.sizeTypes.map(item => {
      if (item.id === id && item.count > 0) {
        return { ...item, count: item.count - 1, error: '' };
      }
      return item;
    });
    this.setData({ sizeTypes }, () => this.calculateFee());
  },

  onPlus(e) {
    const { id } = e.currentTarget.dataset;
    const sizeTypes = this.data.sizeTypes.map(item => {
      if (item.id === id) {
        return { ...item, count: item.count + 1, error: '' };
      }
      return item;
    });
    this.setData({ sizeTypes }, () => this.calculateFee());
  },

  onCountInput(e) {
    const { id } = e.currentTarget.dataset;
    const value = e.detail.value;
    let error = '';
    if (!/^\d*$/.test(value) || parseInt(value) < 0) {
      error = '请输入有效数量';
    }
    const sizeTypes = this.data.sizeTypes.map(item => {
      if (item.id === id) {
        return { ...item, count: parseInt(value) || 0, error };
      }
      return item;
    });
    this.setData({ sizeTypes }, () => this.calculateFee());
  },

  calculateFee() {
    const feeDetails = this.data.sizeTypes.map(item => {
      const amount = item.count * item.price;
      return {
        icon: `/images/${item.id}-icon.png`,
        text: `${item.name}费用：${amount}元（${item.count}件×${item.price}元）`
      };
    }).filter(item => item.text.includes('元（0件'));
    const totalFee = this.data.sizeTypes.reduce((sum, item) => sum + item.count * item.price, 0);
    this.setData({ feeDetails, totalFee }, () => this.checkSubmitStatus());
  },

  checkSubmitStatus() {
    const hasCode = !this.data.codeError && 
                   this.data.expressCodes.length > 0 && 
                   this.data.expressCodes.every(item => item.code && !item.error);
    const hasType = !!this.data.selectedType;
    const hasCount = this.data.sizeTypes.some(item => item.count > 0);
    const hasInfo = this.data.selectedInfoIndex !== -1 && 
                    this.data.pickupInfoList[this.data.selectedInfoIndex].name && 
                    this.data.pickupInfoList[this.data.selectedInfoIndex].phone && 
                    this.data.pickupInfoList[this.data.selectedInfoIndex].address;
    
    // 计算快递总数量
    const totalExpressCount = this.data.sizeTypes.reduce((sum, item) => sum + item.count, 0);
    // 检查取件码数量与快递总数量是否匹配
    const isCountMatch = this.data.expressCodes.length === totalExpressCount;
    
    // 设置错误提示
    let countError = '';
    if (totalExpressCount > 0 && !isCountMatch) {
      countError = `取件码数量（${this.data.expressCodes.length}）与快递数量（${totalExpressCount}）不匹配`;
    }
    
    this.setData({
      countError,
      isSubmitDisabled: !(hasCode && hasType && hasCount && hasInfo && isCountMatch)
    });
  },

  resetForm() {
    this.setData({
      codeError: '',
      infoError: '',
      countError: '',
      expressCodes: [{ code: '', error: '' }],
      selectedType: null,
      sizeTypes: [
        { id: 'large', name: '大件', price: 1.5, count: 0, error: '' },
        { id: 'medium', name: '中件', price: 1, count: 0, error: '' },
        { id: 'small', name: '小件', price: 0.5, count: 0, error: '' }
      ],
      feeDetails: [],
      totalFee: 0,
      isSubmitDisabled: true
    });
  },

  onSubmit() {
    if (this.data.isSubmitDisabled) return;
    // 检查登录状态
    const userInfo = wx.getStorageSync('userInfo');
    // 添加详细日志，检查userInfo结构
    console.log('提交订单时获取的用户信息:', JSON.stringify(userInfo));
    console.log('用户信息中是否包含_id:', !!userInfo._id, 'userId值:', userInfo._id);
    
    if (!userInfo) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    
    // 检查是否选择了取件信息
    if (this.data.selectedInfoIndex === -1 || !this.data.pickupInfoList[this.data.selectedInfoIndex].name) {
      this.setData({ infoError: '请选择有效的取件信息' });
      return;
    }
    
    // 先请求订阅消息权限（在用户点击手势中直接调用）
    wx.requestSubscribeMessage({
      tmplIds: ['byyQTk0ycTcPoW8homGNtROnqW8wheC4exnyHSQ9DdA'],
      success: (subscribeRes) => {
        console.log('订阅消息权限请求结果:', subscribeRes);
        
        // 获取选中的取件信息
        const selectedInfo = this.data.pickupInfoList[this.data.selectedInfoIndex];
        
        // 构造包含用户信息的订单数据
        const orderData = {
          codes: this.data.expressCodes.map(item => item.code), // 存储多个取件码
          code: this.data.expressCodes[0].code, // 保留原字段以兼容旧版
          name: selectedInfo.name,
          phone: selectedInfo.phone,
          address: selectedInfo.address,
          expressType: this.data.expressTypes.find(item => item.id === this.data.selectedType).name,
          sizes: this.data.sizeTypes.map(item => ({
            type: item.id,
            count: item.count,
            price: item.price
          })),
          totalFee: this.data.totalFee,
          createTime: Date.now(), // 使用时间戳而不是Date对象，避免JSON序列化问题
          userId: userInfo._id // 使用登录用户的ID与订单绑定
        };
        
        // 保存订单数据副本到本地缓存，避免被重置
        wx.setStorageSync('pendingOrder', JSON.stringify(orderData));
        
        // 保存订阅状态到本地
        wx.setStorageSync('subscribeStatus', subscribeRes);
        
        wx.showToast({ title: '请完成支付', icon: 'success' });
        
        // 显示收款码弹窗
        setTimeout(() => {
          this.setData({ showPaymentModal: true });
        }, 1000);
      },
      fail: (subErr) => {              console.error('请求订阅消息权限失败:', subErr);
              
              // 获取选中的取件信息
              const selectedInfo = this.data.pickupInfoList[this.data.selectedInfoIndex];
              
              // 构造包含用户信息的订单数据
              const orderData = {
                codes: this.data.expressCodes.map(item => item.code), // 存储多个取件码
                code: this.data.expressCodes[0].code, // 保留原字段以兼容旧版
                name: selectedInfo.name,
                phone: selectedInfo.phone,
                address: selectedInfo.address,
                expressType: this.data.expressTypes.find(item => item.id === this.data.selectedType).name,
                sizes: this.data.sizeTypes.map(item => ({
                  type: item.id,
                  count: item.count,
                  price: item.price
                })),
                totalFee: this.data.totalFee,
          createTime: Date.now(), // 使用时间戳而不是Date对象，避免JSON序列化问题
          userId: userInfo._id
              };
              
              // 保存订单数据到本地缓存
              wx.setStorageSync('pendingOrder', JSON.stringify(orderData));
              wx.setStorageSync('subscribeStatus', null);
              
              wx.showToast({ title: '请完成支付', icon: 'success' });
              
              // 显示收款码弹窗
              setTimeout(() => {
                this.setData({ showPaymentModal: true });
              }, 1000);
              
              // 注意：根据最新需求，订单只会在用户确认支付后才保存到数据库
              // 因此即使订阅消息请求失败，也不会立即提交订单到云函数
            },
            complete: () => {
              // 订阅消息请求完成后的处理
            }
          });
  },
  
  // 关闭弹窗
  onCloseModal() {
    this.setData({ showPaymentModal: false });
  },
  
  // 取消支付
  onPaymentCancelled() {
    this.setData({ showPaymentModal: false });
    this.resetForm();
    
    // 清除本地缓存的待处理订单
    wx.removeStorageSync('pendingOrder');
    wx.removeStorageSync('subscribeStatus');
    
    wx.showToast({ title: '支付已取消', icon: 'none' });
  },
  
  // 确认已支付
  onPaymentConfirmed() {
    this.setData({ showPaymentModal: false });
    
    // 从本地缓存获取待处理订单数据
    const pendingOrderStr = wx.getStorageSync('pendingOrder');
    const subscribeStatus = wx.getStorageSync('subscribeStatus');
    
    if (pendingOrderStr) {
      const orderData = JSON.parse(pendingOrderStr);
      
      // 订单支付完成后，保存订单数据到数据库
      wx.cloud.callFunction({
        name: 'quickstartFunctions',
        data: {
          type: 'submitOrder',
          orderData: orderData
        },
        success: res => {
          if (res.result.success) {
            wx.showToast({ title: '支付成功，订单已保存', icon: 'success' });
            
            // 如果用户之前同意订阅，发送消息
            if (subscribeStatus && subscribeStatus['byyQTk0ycTcPoW8homGNtROnqW8wheC4exnyHSQ9DdA'] === 'accept') {
              console.log('用户已同意订阅消息，准备调用云函数发送消息');
              // 用户同意订阅，调用云函数发送消息给工作人员
              wx.cloud.callFunction({
                name: 'quickstartFunctions',
                data: {
                  type: 'sendStaffSubscribeMessage',
                  orderData: orderData
                },
                success: (msgRes) => {
                  console.log('发送订阅消息云函数调用结果:', msgRes);
                },
                fail: (msgErr) => {
                  console.error('发送订阅消息云函数调用失败:', msgErr);
                }
              });
            }
            
            // 清除本地缓存的待处理订单
            wx.removeStorageSync('pendingOrder');
            wx.removeStorageSync('subscribeStatus');
            
            // 重置表单
            this.resetForm();
            
            // 延迟跳转到我的订单页面
            setTimeout(() => {
              wx.navigateTo({ url: '/pages/order/order' });
            }, 1000);
          } else {
            wx.showToast({ title: '订单保存失败：' + (res.result.errMsg || '未知错误'), icon: 'none' });
          }
        },
        fail: err => {
          console.error('云函数调用失败', err);
          wx.showToast({ title: '网络错误，请重试', icon: 'none' });
        }
      });
    } else {
      wx.showToast({ title: '订单数据不存在', icon: 'none' });
      this.resetForm();
    }
  },
  
  // 长按收款码图片时触发的事件
  onQrCodeLongPress(e) {
    const imageUrl = e.currentTarget.dataset.url;
    
    // 先调用保存图片方法
    this.saveImageToAlbum(imageUrl);
    
    // 保存后显示提示信息
    wx.showModal({
      title: '提示',
      content: '图片已保存到相册，请使用微信扫码付款',
      showCancel: false
    });
  },
  
  // 保存图片功能（可选，仅用于用户需要保存图片的情况）
  saveImageToAlbum(imageUrl) {
    // 获取用户授权保存到相册
    wx.getSetting({
      success: (res) => {
        // 检查是否有保存到相册的权限
        if (!res.authSetting['scope.writePhotosAlbum']) {
          // 请求授权
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success: () => {
              this.saveImage(imageUrl);
            },
            fail: () => {
              // 授权失败，引导用户手动开启
              wx.showModal({
                title: '提示',
                content: '需要您授权保存图片到相册',
                confirmText: '去授权',
                success: (modalRes) => {
                  if (modalRes.confirm) {
                    wx.openSetting({});
                  }
                }
              });
            }
          });
        } else {
          // 已授权，直接保存图片
          this.saveImage(imageUrl);
        }
      }
    });
  },
  
  saveImage(imageUrl) {
    wx.saveImageToPhotosAlbum({
      filePath: imageUrl,
      success: () => {
        wx.showToast({ title: '图片已保存到相册', icon: 'success' });
      },
      fail: (err) => {
        console.error('保存图片失败', err);
        wx.showToast({ title: '保存失败', icon: 'none' });
      }
    });
  }
})