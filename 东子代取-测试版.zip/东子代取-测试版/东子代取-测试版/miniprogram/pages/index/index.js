Page({
  data: {
    selectedTab: 'home'
  },
  onLoad() {
    // 页面加载时的初始化逻辑
  },
  onShow() {
    // 页面显示时的逻辑
  },
  
  // 点击搜索栏进入搜索页面
  onSearchClick() {
    wx.navigateTo({
      url: '/pages/search/search'
    });
  },
  
  // 点击代取手注册卡片
  onCourierRegisterTap() {
    wx.navigateTo({
      url: '/pages/courier-register/courier-register'
    });
  },
  
  // 点击鲜花代取
  onFlowerTap() {
    wx.showModal({
      title: '提示',
      content: '暂未开发，请前往代取快递',
      showCancel: false
    });
  },
  
  // 点击文件代取
  onDocumentTap() {
    wx.showModal({
      title: '提示',
      content: '暂未开发，请前往代取快递',
      showCancel: false
    });
  },
  
  // 点击大件代取
  onBigItemTap() {
    wx.showModal({
      title: '提示',
      content: '暂未开发，请前往代取快递',
      showCancel: false
    });
  }
})