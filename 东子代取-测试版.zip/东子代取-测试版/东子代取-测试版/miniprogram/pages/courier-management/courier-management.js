Page({
  data: {
    courierList: [],
    isLoading: false,
    searchKey: '',
    filterStatus: 'all', // all, active, inactive
    currentPage: 1,
    pageSize: 20,
    hasMore: true,
    totalCouriers: 0,
    activeCouriers: 0,
    inactiveCouriers: 0
  },

  onLoad() {
    this.checkAdminPermission();
    this.getCourierList();
  },

  // 检查管理员权限
  checkAdminPermission() {
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'checkAdmin'
      },
      success: (res) => {
        const isAdmin = res.result && res.result.success && res.result.isAdmin;
        if (!isAdmin) {
          wx.showToast({ title: '您不是管理员，无法访问', icon: 'none' });
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        }
      },
      fail: (err) => {
        console.error('检查管理员权限失败:', err);
        wx.showToast({ title: '权限验证失败', icon: 'none' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      }
    });
  },

  // 获取代取手列表
  getCourierList() {
    if (this.data.isLoading || !this.data.hasMore) return;
    
    this.setData({ isLoading: true });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'getCouriers',
        searchKey: this.data.searchKey,
        status: this.data.filterStatus,
        page: this.data.currentPage,
        pageSize: this.data.pageSize
      },
      success: (res) => {
        if (res.result && res.result.success) {
          const newCouriers = res.result.data || [];
          const updatedList = this.data.currentPage === 1 ? newCouriers : [...this.data.courierList, ...newCouriers];
          
          // 计算统计数据
          const totalCouriers = updatedList.length;
          const activeCouriers = updatedList.filter(item => item.status === 'active').length;
          const inactiveCouriers = updatedList.filter(item => item.status === 'inactive').length;
          
          this.setData({
            courierList: updatedList,
            totalCouriers,
            activeCouriers,
            inactiveCouriers,
            hasMore: newCouriers.length === this.data.pageSize,
            currentPage: this.data.currentPage + 1
          });
        } else {
          wx.showToast({ title: '获取代取手列表失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('获取代取手列表失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        this.setData({ isLoading: false });
      }
    });
  },

  // 搜索代取手
  onSearch(e) {
    const { value } = e.detail;
    this.setData({
      searchKey: value,
      currentPage: 1,
      hasMore: true
    }, () => {
      this.getCourierList();
    });
  },

  // 切换筛选状态
  onFilterChange(e) {
    const { status } = e.currentTarget.dataset;
    this.setData({
      filterStatus: status,
      currentPage: 1,
      hasMore: true
    }, () => {
      this.getCourierList();
    });
  },

  // 切换代取手状态
  onStatusToggle(e) {
    const { id, currentStatus } = e.currentTarget.dataset;
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    
    wx.showModal({
      title: '确认操作',
      content: `确定要将该代取手${newStatus === 'active' ? '启用' : '禁用'}吗？`,
      success: (res) => {
        if (res.confirm) {
          this.updateCourierStatus(id, newStatus);
        }
      }
    });
  },

  // 更新代取手状态
  updateCourierStatus(courierId, status) {
    wx.showLoading({ title: '处理中...' });
    
    wx.cloud.callFunction({
      name: 'quickstartFunctions',
      data: {
        type: 'updateCourierStatus',
        courierId: courierId,
        status: status
      },
      success: (res) => {
        if (res.result && res.result.success) {
          wx.showToast({ title: '操作成功', icon: 'success' });
          // 刷新列表
          this.setData({ currentPage: 1, hasMore: true }, () => {
            this.getCourierList();
          });
        } else {
          wx.showToast({ title: '操作失败', icon: 'none' });
        }
      },
      fail: (err) => {
        console.error('更新代取手状态失败:', err);
        wx.showToast({ title: '网络错误', icon: 'none' });
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },

  // 查看代取手详情
  onCourierDetail(e) {
    const { courier } = e.currentTarget.dataset;
    // 显示代取手详情弹窗
    wx.showModal({
      title: '代取手详情',
      content: `姓名: ${courier.name || '未设置'}\n宿舍: ${courier.dorm || '未设置'}\n电话: ${courier.phone || '未设置'}\n状态: ${courier.status === 'active' ? '活跃' : '禁用'}\n注册时间: ${courier.createTime ? this.formatDate(courier.createTime) : '未知'}`,
      showCancel: false
    });
  },
  
  // 格式化日期
  formatDate(dateString) {
    if (!dateString) return '未知';
    
    // 处理字符串形式的日期
    if (typeof dateString === 'string') {
      if (dateString.includes('T')) {
        // ISO格式日期: 2023-05-15T10:30:00Z
        return dateString.split('T')[0];
      }
      return dateString;
    }
    
    // 处理时间戳形式的日期
    if (typeof dateString === 'number') {
      const date = new Date(dateString);
      return this.formatDateFromDate(date);
    }
    
    // 处理Date对象
    if (dateString instanceof Date) {
      return this.formatDateFromDate(dateString);
    }
    
    // 处理云开发的时间对象
    if (typeof dateString === 'object' && dateString._seconds) {
      const date = new Date(dateString._seconds * 1000);
      return this.formatDateFromDate(date);
    }
    
    return '未知';
  },
  
  // 从Date对象格式化日期
  formatDateFromDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  // 添加新代取手
  onAddCourier() {
    wx.showToast({
      title: '功能开发中',
      icon: 'none'
    });
  },

  // 上拉加载更多
  onReachBottom() {
    this.getCourierList();
  },

  // 返回上一页
  onBackTap() {
    wx.navigateBack();
  }
});